package com.nucleus.Entity;

public class User {

	private String userId;
	
	private String userPassword;
	private int Enabled;
	private String userRole;
	private Authorities authorities;
	
	
	public Authorities getAuthorities() {
		return authorities;
	}


	public void setAuthorities(Authorities authorities) {
		this.authorities = authorities;
	}


	
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}


	public int getEnabled() {
		return Enabled;
	}


	public void setEnabled(int enabled) {
		Enabled = enabled;
	}
	
	
	
	
	
	
}
