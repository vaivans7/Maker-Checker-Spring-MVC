package com.nucleus.Entity;
import java.io.Serializable;
import java.util.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

/*
 * Customer Entity Class Containing Customer Information......
 */


@Entity
@Table(name="customer77")
public class Customer implements Serializable {

	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customer_id;
	
	
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	@Id
	/*@Min(value=100,message="Value cannot be below 100")*/
	private String customer_code;
	
	@Length(min=3, max=20)
	@NotNull
	@Pattern(regexp="^[a-zA-Z0-9\\s]+$")
	private String customer_name;
	
	@NotNull
	@Pattern(regexp="^[a-zA-Z0-9\\s!@#$&()\\-'.+,/\"]*$")
	private String customer_address1;
	
	@NotNull
	@Pattern(regexp="^[a-zA-Z0-9\\s!@#$&()\\-'.+,/\"]*$")
	private String customer_address2;
	
	
	@NotNull
	private Long customer_pincode;
	
	@NotNull
	@Email
	private String email_address;
	
	@NotNull
	/*@Pattern(regexp="^$|[0-9]{10}")*/
	private Long contact_number;
	
	@NotNull
	@Pattern(regexp="^[a-zA-Z0-9\\s]+$")
	@Length(min=3, max=20)
	private String contact_person;
	
	
	private String record_status;
	
	
	private String active_inactive_flag;
	
	
	private java.sql.Date create_date;
	public void setCreate_date(java.sql.Date create_date) {
		this.create_date = create_date;
	}
	
	public String getCreated_by() {
		return created_by;
	}
	private String created_by;
	private Date modified_date;
	private String modified_by;
	private Date authorized_date;
	private String authorized_by;
	
	
	
	/*private Calendar startdate;
	private Calendar enddate;
	public Calendar getStartdate() {
		return startdate;
	}
	public void setStartdate(Calendar startdate) {
		this.startdate = startdate;
	}
	public Calendar getEnddate() {
		return enddate;
	}
	public void setEnddate(Calendar enddate) {
		this.enddate = enddate;
	}*/
	
	
	
	
	
	
	public Date getCreate_date() {
		return create_date;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getAuthorized_date() {
		return authorized_date;
	}
	public void setAuthorized_date(Date authorized_date) {
		this.authorized_date = authorized_date;
	}
	public String getAuthorized_by() {
		return authorized_by;
	}
	public void setAuthorized_by(String authorized_by) {
		this.authorized_by = authorized_by;
	}
	
	
	
	
	public String getCustomer_code() {
		return customer_code;
	}
	public void setCustomer_code(String customer_code) {
		this.customer_code = customer_code;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_address1() {
		return customer_address1;
	}
	public void setCustomer_address1(String customer_address1) {
		this.customer_address1 = customer_address1;
	}
	public String getCustomer_address2() {
		return customer_address2;
	}
	public void setCustomer_address2(String customer_address2) {
		this.customer_address2 = customer_address2;
	}
	public Long getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(Long customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public Long getContact_number() {
		return contact_number;
	}
	public void setContact_number(Long contact_number) {
		this.contact_number = contact_number;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getRecord_status() {
		return record_status;
	}
	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
	public String getActive_inactive_flag() {
		return active_inactive_flag;
	}
	public void setActive_inactive_flag(String active_inactive_flag) {
		this.active_inactive_flag = active_inactive_flag;
	}

	
	
	
	
	
	
	
	
	
	
	
}
