package com.nucleus.Service;

import java.sql.Date;
import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.Dao.UserDao;
import com.nucleus.Dao.UserDaoRDBMS;
import com.nucleus.Entity.Customer;
import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.User;
import com.nucleus.Entity.UserReg;

@Service

public class CustomerServiceImplementation implements CustomerService{

	@Autowired
	UserDao udr;
	
	@Autowired
	SessionFactory sessionFactory;
	
	
	@Override
	@Transactional
	public boolean saveCustomer(Customer customer) {
		
		java.util.Date date=new java.util.Date();
		java.sql.Date sqldate=new java.sql.Date(date.getTime());
		customer.setCreate_date(sqldate);
		
		Session session=sessionFactory.getCurrentSession();
		boolean status=udr.save(customer,session);
		
		
		return status;
	}


	@Override
	@Transactional
	public Customer retriveCustomer(String id) {

		Customer customer=udr.retrive(id);
		
		return customer;
	}


	@Override
	@Transactional
	public ArrayList<Customer> retriveAllCustomer() {
		
		ArrayList<Customer> al=udr.retriveAllCustomer();
		
		return al;
	
	}


	@Override
	@Transactional
	public boolean updateCustomer(Customer customer) {
		
		java.util.Date date=new java.util.Date();
	
		
	
		customer.setModified_date(date);
		customer.setRecord_status("M");
		
		
		
		boolean status=udr.update(customer);
		
		return status;
		
		
	}


	@Override
	@Transactional
	public boolean deleteCustomer(String id) {
		
		
		boolean status=udr.delete(id);
		
		return status;
		
	}


	@Override
	@Transactional
	public boolean saveUser(UserReg userReg,ArrayList<Integer> roleid,ArrayList<String> rolename) {
		userReg.setEnabled(1);
		
		ArrayList<RoleReg>al=new ArrayList<RoleReg>();
		
		
		for(int i=0;i<rolename.size();i++)
		{
			
			RoleReg roleReg=udr.getroleObject(rolename.get(i));
			al.add(roleReg);
		}
		
		
		
	
	
		
		userReg.setAl(al);
		
		udr.saveUser(userReg);
		return true;
	}


	@Override
	@Transactional
	public int getRoleId(String role) {
		
	 int a=udr.roleId(role);
		
		return a;
	}


	@Override
	@Transactional
	public ArrayList<String> getRoles(int roleid) {
		
		ArrayList<String> role=udr.Roles(roleid);
		
		return role;
	}


	@Override
	@Transactional
	public boolean primaryCheck(String code) {
		

		
		
		
		Customer customer=udr.retrive(code);
		
		if(customer!=null)
		{
			return false;
		}
		
		
		else
		{
			return true;
		}
		
		
	}
	


	@Override
	@Transactional
	public ArrayList<String> getRoles() {
		
     ArrayList<String> role=udr.Roles();
		
		return role;
		
	}


	@Override
	@Transactional
	public ArrayList<Customer> retriveDateService(java.sql.Date date1, java.sql.Date date2) {
	
		
		ArrayList<Customer>al=udr.retriveDate(date1, date2);
		
		return al;
	}

}
