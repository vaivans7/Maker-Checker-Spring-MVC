package com.nucleus.Service;

import java.sql.Date;
import java.util.ArrayList;

import com.nucleus.Entity.Customer;
import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.User;
import com.nucleus.Entity.UserReg;

public interface CustomerService {

	public boolean saveCustomer(Customer customer);
	
	public Customer retriveCustomer(String id);
	
	public ArrayList<Customer> retriveAllCustomer();
	
	public boolean updateCustomer(Customer customer);
	
	public boolean deleteCustomer(String id);
	
	public boolean saveUser(UserReg userReg,ArrayList<Integer> roleid,ArrayList<String> rolename); 
	
	public int getRoleId(String role);
	
	
	public ArrayList<String> getRoles(int roleid);
	
	public ArrayList<String> getRoles();
	
	public boolean primaryCheck(String code);
	
	
	
	public ArrayList<Customer> retriveDateService(java.sql.Date date1,java.sql.Date date2);
	
	
}
