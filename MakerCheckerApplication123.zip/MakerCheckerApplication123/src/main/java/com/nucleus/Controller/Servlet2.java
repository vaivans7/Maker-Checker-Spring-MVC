package com.nucleus.Controller;

import java.security.Principal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthoritiesContainer;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.Entity.Customer;
import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.UserReg;
import com.nucleus.Service.CustomerService;
import com.nucleus.Service.CustomerServiceImplementation;

/*
Main Controller Containing Login And Crud Operations

*/

@Controller
public class Servlet2 {
	
	//Logger Class Instantiaton
	public final static Logger logger=Logger.getLogger(com.nucleus.Dao.UserDaoRDBMS.class);
	
	
	@Autowired
	CustomerService  customerServiceImplementation; //Service class bean..
	
	
	@RequestMapping("/userlogin")  //user login mapping....
	public String UserLogin()
	{
		
		return "User";
		
		
		
	}
	
	
	@RequestMapping("/loginfailure")    // login failure mapping.....
	public String UserLoginFailure()
	{
		
		return "User";
		
		
		
	}
	
	
	
	
	
/*	@RequestMapping("/defaultpage")
	public String UserLogin1(HttpServletRequest request,HttpServletResponse response)
	{
		
		String target=null;
		
		if(request.isUserInRole("ROLE_MAKER"))
		{
				target="first";
		}
		
		
		if(request.isUserInRole("ROLE_CHECKER"))
		{
			target="checkerfirst";
		}
		
		if(request.isUserInRole("ROLE_ADMIN"))
		{
			target="userregister";
		}
		
		
		return target;
		
	}*/
	
	@RequestMapping("/common")  // common page mapping showing all the role of the login user....
	public String commonRequest(Authentication authentication,Principal principal,Model model,@RequestParam("role") String role,UserReg userReg)
	{
		 ArrayList<String> al=new ArrayList<String>();
			String target=null;
			for(GrantedAuthority authority : SecurityContextHolder.getContext().getAuthentication().getAuthorities())
			{
				
				
				String userRole=authority.getAuthority();
				
				al.add(userRole);
				
				
				
				
		
			
				
			}
			
			
			if(al.contains(role))
			{
				if(role.equals("ROLE_MAKER"))
				{
					target="first";
				}
				
				if(role.equals("ROLE_ADMIN"))
				{
					 String id=principal.getName();
						
						Integer uid=Integer.parseInt(id);
						
						ArrayList<String> role1=customerServiceImplementation.getRoles();
						
						
						
					model.addAttribute("role1",role1);	
					
				
					
					model.addAttribute(userReg);
					target="userregister";
				}
				
			}
			
			else
			{
				
			}
		
		
		return target;
		
		
		
		
		
	}
	
	
	// After logging specific page to be owned based on the role of the user....
	@RequestMapping("/defaultpage")
	public String UserLogin1(Model model,Principal principal)
	{
		String id=principal.getName();
		
		Integer uid=Integer.parseInt(id);
		
		
        ArrayList<String> role=customerServiceImplementation.getRoles(uid);
		
        
        System.out.println("--------------------");
       // System.out.println(uid);
        System.out.println(role);
        
        /*for(int i=0;i<role.size();i++)
        {
        	System.out.println(role.get(i).getRole());
        }*/
        
		model.addAttribute("role",role);
		
		
		
		
		return "commonlogin";
		
	}
	
	
	
	
	
	/*
	@RequestMapping("/logout")
	public String Logout()
	{
		
		return "User";
		
	   // return new ModelAndView("result","value","5");
		
		
	}*/
	
	// Access Denied Page Mapping
	
	@RequestMapping("/accessdenied")
	public ModelAndView accessDenied(Model model)
	{
		model.addAttribute("statusdenied","No access");
		return new ModelAndView("User");
	}
	
	
	// Crud Operations Page Opening Mapping......
	
	@RequestMapping("/controlfirst")
	public ModelAndView Create(@RequestParam("crud") String crud,Customer customer)
	{
		
		
		String target=null;
		if(crud.equals("create"))
		{
		/*target="Customer";
		return new ModelAndView("Customer",customer);*/
			
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
			
				
			
			
			ModelAndView model=new ModelAndView("Customer");
			model.addObject("customer",customer);
			model.addObject("myList",al);
			return model;
			
		}
		
		if(crud.equals("retrive"))
		{
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
				
				
				
				
				ModelAndView model=new ModelAndView("retrivecustomer");
				
				
				model.addObject("myList",al);
				return model;
			
			
		}
		
		
		if(crud.equals("retriveall"))
		{
		
			ModelAndView model=new ModelAndView("forward:/retriveallcont");
			return model;
			
		}
		
		
		if(crud.equals("update"))
		{
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
				
				
				
				
				ModelAndView model=new ModelAndView("updatecustomer");
				
				
				model.addObject("myList",al);
				return model;
			
			
			
		
			
		}
		
		
		if(crud.equals("delete"))
		{
			
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
				
				
				
				
				ModelAndView model=new ModelAndView("deletecustomer");
				
				
				model.addObject("myList",al);
				return model;
			
			
			
			
			
		}
		
		
		
		
		ModelAndView model=new ModelAndView(target);
		
		return model;
		
		
		
	}
	
	
	//Customer Saving Form Mapping To Be Saved To Database.....
	
	@RequestMapping("/saveCustomer")
	public ModelAndView SaveCustomer(@Valid Customer customer,BindingResult result,Principal principal)
	{
	
		ModelAndView model=null;
		if(result.hasErrors())
		{
			
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
				
				
				
				
				 model=new ModelAndView("Customer");
				model.addObject("customer",customer);
				model.addObject("myList",al);
				model.addObject("status","Customer Records Validation Failed....");
				
			
			logger.info("Server Side Validations Failed....");
			return model;
			
		}
		
		else{
		
		
			
		   boolean status=customerServiceImplementation.primaryCheck(customer.getCustomer_code());
		
		   
			if(status==true){
			
			model=new ModelAndView("Customer");
		customer.setCreated_by(principal.getName());
		customer.setRecord_status("N");
		
	
		
	
		
		boolean status1=customerServiceImplementation.saveCustomer(customer);
		 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
			model.addObject("myList",al);
		
		if(status1)
		{
			model.addObject("status","Customer Information Saved Sucessfully.....");
			
	
		}
		else
		{
			model.addObject("status","Customer Information Can't be saved.....");
		}
		
		}
		
		
		
		else{
			
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				
				
				
				
				
				
			 model=new ModelAndView("Customer");
			model.addObject("customer",customer);
			model.addObject("myList",al);
			model.addObject("status","Customer Code Already Exists....");
		}
		
		}
		return model;
	}
	
	
	//Retrive Single Page Openining Mapping.....
	
	@RequestMapping("/retrivesingle")
	public ModelAndView retriveSingle(@RequestParam("uid") String id)
	{
		
		Customer customer=customerServiceImplementation.retriveCustomer(id);
		ModelAndView model=null;
		if(customer!=null)
		{
		
		model=new ModelAndView("retrivecustomer2");
		model.addObject("myobject",customer);
		 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
			model.addObject("myList",al);
		
		
		}
		
		else{
		model=new ModelAndView("retrivecustomer2");
			model.addObject("status","Cannot Retrive Data.....");
			 ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
				model.addObject("myList",al);
			
		}
		
		
		return model;
	}
	
	
	// Retrive all page opening mapping....
	
	@RequestMapping("/retriveallcont")
	public ModelAndView retriveAll()
	{
		
	   ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
		
		ModelAndView model=new ModelAndView("retriveall");
		model.addObject("myList",al);
		
		return model;
	}
	
	//Update Customer Mapping
	
	@RequestMapping("/updatecustomer")
	//public ModelAndView updateretrive(@RequestParam("uid") String id,Customer customer)
	public ModelAndView updateretrive(@RequestParam("uid") String id)
	{
		Customer customer=customerServiceImplementation.retriveCustomer(id);
		
		/*java.util.Date date = new java.util.Date();
       java.sql.Date sqldate=new java.sql.Date(date.getTime());
		customer.setCreate_date(sqldate);*/
System.out.println("..................................." + customer.getCustomer_code());
		
       //Customer customer1=customerServiceImplementation.retriveCustomer(id);
		/*ModelAndView model=null;*/

      /*if(customer!=null)
      {
    	  ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
	    model=new ModelAndView("updatecustomer2");
		model.addObject("myList",al);
		model.addObject("cust",customer1);
		
		
		
	
      }
      
      
      else
      {
    	  model=new ModelAndView("updatecustomer");
    	  ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
    	  model.addObject("myList",al);
    	  
    
  		model.addObject("status","Customer Does Not Exists.....");
      }*/
      
		ModelAndView model=new ModelAndView("updatecustomer2");
		model.addObject("customer",customer);
		  ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
    	  model.addObject("myList",al);
		
	   return model;
		
	
	}
	
	
	
	//Saving Updated Info to service and dao layers.....

	@RequestMapping("/updatecust")
	public ModelAndView UpdateCustomer(Customer customer,Principal principal)
	{
		
		customer.setModified_by(principal.getName());
		
	    boolean flag=customerServiceImplementation.updateCustomer(customer);
		
	    ModelAndView model=new ModelAndView("updatecustomer");
	    
 
	    
		
		if(flag==true)
		{
		
			model.addObject("status","Update Successfull.....");
		}
		
		else
		{
			
			model.addObject("status","Updation Failed");
		}
		
		model.addObject(customer);
		
		  ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
		  model.addObject("myList",al);
		
		
		return model;
	}
	
	
	
	// delete customer mapping......
	
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomer(@RequestParam("uid") String id,Customer customer)
	{
       
		boolean status=customerServiceImplementation.deleteCustomer(id);
		
		ModelAndView model=new ModelAndView("deletecustomer");
		
		if(status)
		{
			
			  ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
			  model.addObject("myList",al);
			
			
		model.addObject("status","Record Deleted Successfully....");
		}
		
		
		else
		{
			ArrayList<Customer> al=customerServiceImplementation.retriveAllCustomer();
			  model.addObject("myList",al);
			
			model.addObject("status","Record Cannot Be Deleted....");
		}
		
		return model;
	  
		
	
	}
	
	
	
	
	
	
	@RequestMapping("/datesort")    
	public ModelAndView DateSort(HttpServletRequest request,HttpServletResponse response,Customer customer)
	{
		
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		
		ModelAndView model=new ModelAndView("Customer");
		
		 System.out.println("***************STRINGDATES");
		  System.out.println(startdate);
		  System.out.println(enddate);
		  System.out.println("***************");
		  
		  
		  String newstartdate=startdate.replace('-','/');
		  
		  String newenddate=enddate.replace('-','/');
		  
	   
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date date1=null;
		java.util.Date date2=null;
		try {
			date1 = formatter.parse(newstartdate);
			 date2= formatter.parse(newenddate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		/* DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	        
			

	        LocalDate localDate1 = (LocalDate) formatter1.parse(startdate);
		
	        LocalDate localDate2 = (LocalDate) formatter1.parse(enddate);
	        
	        
	    	System.out.println("***************localutildATES");
			  System.out.println(localDate1);
			  System.out.println(localDate2);
			  System.out.println("***************");
			*/
	        
		
		/*SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		
		java.util.Date datecal=null;
		try {
			 datecal = sdf.parse(startdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
               java.util.GregorianCalendar calender=new java.util.GregorianCalendar();
		 calender.setTime(datecal);
		 
		 System.out.println("?????????????????");
		 System.out.println(calender);
               */
               
               
		/*Calendar calender1 = Calendar.getInstance();
		Calendar calender2 = Calendar.getInstance();
		calender1.setTime(date1);
		calender2.setTime(date2);*/
		
		
	/*	customer.setStartdate(calender1);
		customer.setEnddate(calender2);
		*/
		/*String sDate1=datefirst;
		String sDate2=datesecond;*/
	/*	Calendar date11=customer.getStartdate();
		Calendar date12=customer.getEnddate();*/
		
		
		
		
		
	   /*  java.util.Date date111=calender1.getInstance().getTime();
	     java.util.Date date222=calender2.getInstance().getTime();*/
		
		
		System.out.println("***************utildATES");
		  System.out.println(date1);
		  System.out.println(date2);
		  System.out.println("***************");
		
		
		
		
	   java.sql.Date sqldate1=new java.sql.Date(date1.getTime());
		
	   java.sql.Date sqldate2=new java.sql.Date(date2.getTime());
	   

		  System.out.println("***************SQLDATES");
		  System.out.println(sqldate1);
		  System.out.println(sqldate2);
		  System.out.println("***************");
	   
	   
		 
		  
	  ArrayList<Customer>al=customerServiceImplementation.retriveDateService(sqldate1, sqldate2);
	   System.out.println("///////////////");
	   System.out.println(al);
	   System.out.println("///////////////"); 
	
	  
	   model.addObject("myList",al);
	   model.addObject(customer);
		
		return model;
		
	}
	

}