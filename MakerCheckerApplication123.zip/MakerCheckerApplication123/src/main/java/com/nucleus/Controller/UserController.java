package com.nucleus.Controller;


/*
User Controller Contains Code Regarding User Registration....
*/

import java.security.Principal;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.User;
import com.nucleus.Entity.UserReg;
import com.nucleus.Service.CustomerService;
import com.nucleus.Service.CustomerServiceImplementation;
import com.nucleus.util.PasswordEncoder;

@Controller
public class UserController {
	
	@Autowired
	CustomerService  customerServiceImplementation;
	
	@RequestMapping("/cuser")    // User Registration Form Mapping
	public ModelAndView UserLogin(UserReg userReg,Principal principal)
	{
         String id=principal.getName();
		
		Integer uid=Integer.parseInt(id);
		
		ArrayList<String> role=customerServiceImplementation.getRoles();
		
		ModelAndView model=new ModelAndView("userregister");
		
		model.addObject("role",role);
		model.addObject(userReg);
		
	
		return model;
	}
	@RequestMapping("/cuserRegister")   // User RegistrationSaving Form Mapping 
	public ModelAndView userRegister(UserReg userReg,RoleReg roleReg,Model model,@RequestParam("rolename") String[] var)
	{	
		
		
		PasswordEncoder pen=new PasswordEncoder();
		
		String password=userReg.getUser_password();
		userReg.setUser_password(pen.encodePwd(password));
		
		
		
		
		
		
		
		
		
		
		ArrayList<Integer> roleid=new ArrayList<Integer>();
		ArrayList<String> rolename=new ArrayList<String>();
		
		
		
		
		
		
		
		
		for(int i=0;i<var.length;i++)
		{
			rolename.add(var[i]);
			
		}
		
		
		
	/*	String rolemaker=request.getParameter("ROLE_MAKER");
		String rolechecker=request.getParameter("rolechecker");
		String roleadmin=request.getParameter("roleadmin");*/
		
		
		
		/*if(rolemaker!=null)
		{
			int a=customerServiceImplementation.getRoleId(rolemaker);
			roleid.add(a);
			rolename.add(rolemaker);
			
		}
		
		if(rolechecker!=null)
		{
			int a=customerServiceImplementation.getRoleId(rolechecker);
			roleid.add(a);
			rolename.add(rolechecker);
		}
		
		if(roleadmin!=null)
		{
			int a=customerServiceImplementation.getRoleId(roleadmin);
			roleid.add(a);
			rolename.add(roleadmin);
			
		}*/
		
		

		
		
		
		customerServiceImplementation.saveUser(userReg,roleid,rolename);
		model.addAttribute("status","registered");
		return new ModelAndView("User");
	}
	
	
	
	@RequestMapping("/home")
	public String homePage()
	{
        
	
		return "first";
	}
	

	
	
	@RequestMapping("/homelogin")
	public String homeloginPage()
	{
        
	
		return "User";
	}
	
	
	

}
