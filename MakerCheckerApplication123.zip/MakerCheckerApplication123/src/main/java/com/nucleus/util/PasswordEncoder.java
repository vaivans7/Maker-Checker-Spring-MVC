package com.nucleus.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordEncoder {

	
	public static String encodePwd(String password)
	{
		
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		
		return encoder.encode(password);
		
		
	}
	
	
	public static void main(String[]args)
	{
		
		System.out.println(encodePwd("123456"));
		System.out.println(encodePwd("123456"));

		
		
	}
	
	
	
}
