package com.nucleus.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import com.nucleus.Dao.UserDaoRDBMS;

/*
 *Logging Class Containg Aspect and Point Cut Details..... 
 * Logger Class Instantiation....
 *
 */


@Aspect
@Component
public class LoggingAspect {

	public final static Logger logger=Logger.getLogger(com.nucleus.aop.LoggingAspect.class);

	@Around("execution(* com.nucleus.Dao.UserDaoRDBMS.*(..))")
	public Object advice1(ProceedingJoinPoint pjp)
	{
		Object object=null;
		
		logger.info("Method name:"+pjp.getSignature().getName()+" Started Exceution....");
		
		Object[] obj=pjp.getArgs();
		
		
		try {
			 object=pjp.proceed();
		
			
		} catch (Throwable e) {
		
			logger.error(e.getMessage());
			
		}
		
		logger.info("Method name:"+pjp.getSignature().getName()+" End Exceution....");
		
		return object;
	}
	
	

	
}
