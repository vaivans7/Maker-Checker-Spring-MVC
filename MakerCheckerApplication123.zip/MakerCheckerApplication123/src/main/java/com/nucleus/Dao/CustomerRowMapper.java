package com.nucleus.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.Entity.Customer;

public class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		
		
		Customer customer=new Customer();
		
		customer.setCustomer_code(rs.getString("customer_code"));
		customer.setCustomer_name(rs.getString("custome_name"));
		customer.setCustomer_address1(rs.getString("customer_address1"));
		customer.setCustomer_address2(rs.getString("customer_address2"));
		customer.setCustomer_pincode(rs.getLong("customer_pincode"));
		customer.setEmail_address(rs.getString("email_address"));
		customer.setContact_number(rs.getLong("contact_number"));
		customer.setContact_person(rs.getString("contact_person"));
		customer.setRecord_status(rs.getString("record_status"));
		customer.setActive_inactive_flag(rs.getString("active_inactive_flag"));
		
		
		
		return customer;
	}

}
