package com.nucleus.Dao;


import java.sql.Date;

/*
 * User Dao Inteface containing all the abstarct methods of the dao layer....
 */


import java.util.ArrayList;

import org.hibernate.Session;

import com.nucleus.Entity.Customer;
import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.User;
import com.nucleus.Entity.UserReg;

public interface UserDao {

	public boolean save(Customer customer,Session session);
	
	public Customer retrive(String id);
	
	public ArrayList<Customer> retriveAllCustomer();
	
	public boolean update(Customer customer);
	
	public boolean delete(String id);
	
	public boolean saveUser(UserReg userReg);
	
	public int roleId(String role);
	
	public ArrayList<String> Roles(int uid);
	
	public ArrayList<String> Roles();
	
	
	public ArrayList<Customer> retriveDate(java.sql.Date date1,java.sql.Date date2);
	
	
	public RoleReg getroleObject(String rolename);
	
	
	
	
	
	
}
