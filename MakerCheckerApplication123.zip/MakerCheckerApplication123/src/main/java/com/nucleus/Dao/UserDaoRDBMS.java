package com.nucleus.Dao;

/*
 * UserDaoRDBMS Implementation Class Containing implementation of the all the abstarct methods of the User Dao Interface.....
 * 
 */



import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.Entity.Customer;
import com.nucleus.Entity.RoleReg;
import com.nucleus.Entity.User;
import com.nucleus.Entity.UserReg;

@Repository

public class UserDaoRDBMS implements UserDao{

	/*public final static Logger logger=Logger.getLogger(com.nucleus.Dao.UserDaoRDBMS.class);*/
	
	
	static Customer customer1=null;
	
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	
	@Autowired
	SessionFactory sessionFactory;
		
	/*
	 * Customer Save Methodusing Session and Transaction  
	 * @see com.nucleus.Dao.UserDao#save(com.nucleus.Entity.Customer, org.hibernate.Session)
	 */
		@Transactional
		public boolean save(Customer customer,Session session) {
			//sessionFactory.getCurrentSession().persist(customer);
			
			
			session.persist(customer);
			
			return true;
			
			
		}
	
	
	
	
	/*@Override
	public boolean save(Customer customer) {
		
		java.sql.Date sqldate=new java.sql.Date(customer.getCreate_date().getTime());
		
Object obj[]={101,customer.getCustomer_code(),customer.getCustomer_name(),customer.getCustomer_address1(),customer.getCustomer_address2(),customer.getCustomer_pincode(),customer.getEmail_address(),customer.getContact_number(),customer.getContact_person(),customer.getRecord_status(),customer.getActive_inactive_flag(),sqldate,customer.getCreated_by(),null,null,null,null};
		
		int a=jdbcTemplate.update("insert into customer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",obj);
		
		if(a==1)
		{
			return true;
		}
		
		else
		{
			logger.info("Data Cannot be saved to database");
			return false;
		}
	}*/

	@Override
	
	/*
	 * Retriving Customer Object 
	 * @see com.nucleus.Dao.UserDao#retrive(java.lang.String)
	 */
	
	public Customer retrive(String id) {
		
		Customer customer=null;
	
		try{
		
		Session session=sessionFactory.getCurrentSession();
	
		Query query1=session.createQuery("from Customer where customer_code=:custcode");
		
		query1.setParameter("custcode",id);
		
	     customer=(Customer)query1.list().get(0);
		
		
		}
		
		catch(Exception e)
		{
			customer=null;
		}
		
		
		return customer;
		
	}

	@Override
	
	/*
	 * Returns Array List Of All the customers from the database.....
	 * @see com.nucleus.Dao.UserDao#retriveAllCustomer()
	 */
	
	public ArrayList<Customer> retriveAllCustomer() {
	
     
		ArrayList<Customer> al=new ArrayList<Customer>();
		Session session=sessionFactory.getCurrentSession();
		
		Query query1=session.createQuery("from Customer");
		
		al=(ArrayList<Customer>) query1.list();
		
		return al;
		
	}

	@Override
	/*
	 * Updates the Existing Customer On basis of customer code.....
	 * @see com.nucleus.Dao.UserDao#update(com.nucleus.Entity.Customer)
	 */
	
	public boolean update(Customer customer) {
		

	
        
		
		
   Session session=sessionFactory.getCurrentSession();
  
    session.update(customer);
   
		return true;
		
		
	}

	@Override

	/*
	 * Deletes the Customer On basis of Customer Code.....
	 * @see com.nucleus.Dao.UserDao#delete(java.lang.String)
	 */
	
	public boolean delete(String id) {
	
	Session session=sessionFactory.getCurrentSession();
	
	Query query1=session.createQuery("delete from Customer where customer_code=:code");
	query1.setParameter("code",id);
	int a=query1.executeUpdate();
	
	if(a==1)
	{
		return true;
	}
	
	else
	{
		return false;
	}
	
		
		
		
	}

	@Override
	
	/*
	 * Saves the New user details to the database.....
	 * @see com.nucleus.Dao.UserDao#saveUser(com.nucleus.Entity.UserReg)
	 */
	
	public boolean saveUser(UserReg userReg) {
		/*Object obj[]={user.getUserId(),user.getUserPassword(),user.getEnabled()};
		jdbcTemplate.update("insert into user_77 values(?,?,?)",obj);
		Object obj1[]={user.getUserId(),user.getAuthorities().getRole()};
		jdbcTemplate.update("insert into userrole_77 values(?,?)",obj1);*/
		
		Session session=sessionFactory.getCurrentSession();
		
		
	   session.persist(userReg);
		
		
		return true;
	}




	@Override
	
	public int roleId(String role) {
		
		Session session=sessionFactory.getCurrentSession();
		
		
		Query query1=session.createQuery("select roleid from RoleReg where role=?");
		query1.setParameter(0,role);
		
	
		
		int a=(Integer)query1.list().get(0);
		
		return a;
	}




	@Override
	
	/*
	 * Returns the array list of all the roles.....
	 * @see com.nucleus.Dao.UserDao#Roles(int)
	 */
	
	public ArrayList<String> Roles(int uid) {
	
		ArrayList<String> al=new ArrayList<String>();
		Session session=sessionFactory.getCurrentSession();
		
		//Query query1=session.createQuery("from RoleReg");
		
		Query query2=session.createSQLQuery("select role from rolereg join user_role_reg1 on(rolereg.roleid=user_role_reg1.role_id) where user_role_reg1.user_id=?");
		query2.setParameter(0,uid);
				
		al=(ArrayList<String>) query2.list();
		
		return al;
		
		
		
		
	}








	@Override
	
	public ArrayList<String> Roles() {
		
		ArrayList<String> al=new ArrayList<String>();
		Session session=sessionFactory.getCurrentSession();
		
		
		
		Query query2=session.createQuery("from RoleReg");
		
		al=(ArrayList<String>) query2.list();
		
		return al;
		
		
	}




	@Override
	
	/*
	 * Gives the Role Object from the table on basis of rolename....
	 * @see com.nucleus.Dao.UserDao#getroleObject(java.lang.String)
	 */
	
	public RoleReg getroleObject(String rolename) {
		Session session=sessionFactory.getCurrentSession();
		
		/*Query query2=session.createQuery("from RoleReg");*/
		Query query2=session.createQuery("from RoleReg where role=:rolename");
		query2.setParameter("rolename",rolename);
		
		RoleReg roleReg=(RoleReg) query2.list().get(0);
		
		return roleReg;
	}




	@Override
	public ArrayList<Customer> retriveDate(java.sql.Date date1, java.sql.Date date2) {
		
		
		Session session=sessionFactory.getCurrentSession();
		
		
		
	/*	Query query2=session.createSQLQuery("select * from customer7757 where create_date between ? and ?");*/
		Query query2=session.createQuery("from Customer where create_date between ? and ?");
	
		query2.setParameter(0,date1);
		query2.setParameter(1,date2);
		
		ArrayList<Customer>al=(ArrayList<Customer>) query2.list();
		
		return al;
	}






}
