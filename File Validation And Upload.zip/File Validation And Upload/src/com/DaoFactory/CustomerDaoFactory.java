package com.DaoFactory;
import com.nucleus.dao.*;
import com.nucleus.Entity.*;
public class CustomerDaoFactory {

	
	
	
	public void demo()
	{
		
		
	}
	
	
	static public CustomerDao getCustomerDaoObject(String type)
	{
		
		CustomerDao customerdao=null;
		
		if(type.equals("rdbms"))
		{
			customerdao=new CustomerRdbmsDaoImplementation();
		}
		/*
		else if(type.equals("xml"))
		{
			studentDao=new StudentXmlDaoImplementation();
		}
		*/
		
		
		
		return customerdao;
	}
	
	
	
}
