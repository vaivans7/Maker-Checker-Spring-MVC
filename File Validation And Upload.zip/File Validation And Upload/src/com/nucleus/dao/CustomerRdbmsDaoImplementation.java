package com.nucleus.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.SQLException;



import com.nucleus.Entity.Customer;

public class CustomerRdbmsDaoImplementation implements CustomerDao{

	
	  PreparedStatement ptmt=null;
	@Override
	public void save(Customer c,Connection con) throws SQLException{
		
	try{
		  	ptmt=con.prepareStatement("insert into customer7757 values(cust_seq11.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
	
			ptmt.setString(1,c.getCustomer_code());
			ptmt.setString(2,c.getCustomer_name());
			ptmt.setString(3,c.getCustomer_address1());
			ptmt.setString(4,c.getCustomer_address2());
			ptmt.setLong(5,c.getCustomer_pincode());
			ptmt.setString(6,c.getEmail_address());
			ptmt.setLong(7,c.getContact_number());
			ptmt.setString(8,c.getContact_person());
			ptmt.setString(9,c.getRecord_status());
			ptmt.setString(10,c.getActive_inactive_flag());
			ptmt.setString(11,c.getCreate_date());
			ptmt.setString(12,c.getCreated_by());
			ptmt.setString(13,c.getModified_date());
			ptmt.setString(14,c.getModified_by());
			ptmt.setString(15,c.getAuthorized_date());
			ptmt.setString(16,c.getAuthorized_by());
			
			ptmt.executeUpdate();
	}
		
		finally{	
			
		ptmt.close();
		}
		
	}

	

}
