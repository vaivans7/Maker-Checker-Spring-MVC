package com.nucleus.dao;
import java.sql.*;
import java.util.*;
import com.nucleus.Entity.*;

public interface CustomerDao {
	
	
	public void save(Customer c,Connection con)throws SQLException;
	

}
