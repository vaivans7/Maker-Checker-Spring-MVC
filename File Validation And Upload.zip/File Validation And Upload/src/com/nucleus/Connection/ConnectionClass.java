package com.nucleus.Connection;


import java.io.*;
import java.util.*;
import java.sql.*;
import java.sql.DriverManager;

public class ConnectionClass {
	
	
  FileReader fr=null;
  BufferedReader br=null;
  
  public Connection getDBConnection()
	{
		Connection con=null;
		try {
			
			fr=new FileReader("db.properties");
			 br=new BufferedReader(fr);
			
			Properties p=new Properties();
			p.load(fr);
			
			
			String str1=p.getProperty("connection");
			String str2=p.getProperty("driver")+p.getProperty("ip")+p.getProperty("port")+p.getProperty("sid");
			
			
		Class.forName(str1);
	    con=DriverManager.getConnection(str2,p.getProperty("username"),p.getProperty("password"));
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			try{
			br.close();
			fr.close();
			
			}
			
			catch(IOException e)
			{
			   e.printStackTrace();
			   
			}
		}
		
		
		return con;
	}
	
	

}


