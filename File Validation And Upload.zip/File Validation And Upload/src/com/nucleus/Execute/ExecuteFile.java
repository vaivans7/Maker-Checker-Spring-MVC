package com.nucleus.Execute;
import java.io.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.nucleus.Entity.Customer;
import java.util.*;
public class ExecuteFile {

	/*
	 public Date convert(String date)
	{
		 String sdate=date;

		 Date date1=null;
		try {
			date1 = new SimpleDateFormat("yyyy/mm/dd").parse(sdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		 return date1;
		
		
	}
	*/
	
	FileReader fr;
	
	 BufferedReader br;
	
	
	
	public ArrayList<Customer> read(String name) throws IOException
	{
		
		
	    ArrayList<Customer> al=new ArrayList<>();
		String word[];
		String word1[]=name.split("\\.");
		
			
			   try{
				   
				   
				  fr=new FileReader(name);
			

				   br=new BufferedReader(fr);
				
				   String line=br.readLine();
				   
				 
				   
				   
				   
				   
				   
				   
				   while(line !=null)
				   {
				   word=null;
				   
				   word=line.split("~",-1);
				   
				  
				   
				   
				   Customer c=new Customer();
				  
				   
				   
				   for(int temp=0;temp<word.length;temp++)
				   {
					   
					  if(word[temp].length()==0)
					  {
						
						  if(temp==0)
						  {
							  c.setCustomer_code("");
							  
						  }
						  
						  else if(temp==1)
						  {
							  c.setCustomer_name("");
							  
						  }
						  else if(temp==2)
						  {
							  
							  c.setCustomer_address1("");
							  
						  }
						  
						  else if(temp==3)
						  {
							  c.setCustomer_address2("");
							  
						  }
						  
						  else if(temp==4)
						  {
							  c.setCustomer_pincode(0);
							  
						  }
						  
						  else if(temp==5)
						  {
							  c.setEmail_address("");
							
						  }
						  
						  else if(temp==6)
						  {
							  c.setContact_number(0);
						
						  }
						  
						  else if(temp==7)
						  {
							  c.setContact_person("");
							 
						  }
						  
						  else if(temp==8)
						  {
							  c.setRecord_status("");
							
						  }
						  
						  
						  else if(temp==9)
						  {
							  c.setActive_inactive_flag("");
							 
						  }
						  
						  else if(temp==10)
						  {
							  c.setCreate_date("");
							  
						  }
						  
						  else if(temp==11)
						  {
							  c.setCreated_by("");
							  
						  }
						  
						  else if(temp==12)
						  {
							  c.setModified_date("");
							  
						  }
						  
						  
						  else if(temp==13)
						  {
							  c.setModified_by("");
							  
						  }
						  
						  else if(temp==14)
						  {
							  c.setAuthorized_date("");
							
						  }
						  
						  else if(temp==15)
						  {
							  c.setAuthorized_by("");
							 
						  }
						  
						  
					  }
					  
					  
					  else{
					   
						  if(temp==0)
						  {
							  c.setCustomer_code(word[temp]);
							 
						  }
						  
						  else if(temp==1)
						  {
							  c.setCustomer_name(word[temp]);
							 
						  }
						  else if(temp==2)
						  {
							  
							  c.setCustomer_address1(word[temp]);
							 
						  }
						  
						  else if(temp==3)
						  {
							  c.setCustomer_address2(word[temp]);
							  
						  }
						  
						  else if(temp==4)
						  {
							  long l=Long.parseLong(word[temp]);
							  c.setCustomer_pincode(l);
						
						  }
						  
						  else if(temp==5)
						  {
							  c.setEmail_address(word[temp]);
							  
						  }
						  
						  else if(temp==6)
						  {
							  long t=Long.parseLong(word[temp]);
							  c.setContact_number(t);
							
						  }
						  
						  else if(temp==7)
						  {
							  c.setContact_person(word[temp]);
							  
						  }
						  
						  else if(temp==8)
						  {
							  c.setRecord_status(word[temp]);
							 
						  }
						  
						  
						  else if(temp==9)
						  {
							  c.setActive_inactive_flag(word[temp]);
							 
						  }
						  
						  else if(temp==10)
						  {
							  c.setCreate_date(word[temp]);
							 
						  }
						  
						  else if(temp==11)
						  {
							  c.setCreated_by(word[temp]);
							
						  }
						  
						  else if(temp==12)
						  {
							  c.setModified_date(word[temp]);
							 
						  }
						  
						  
						  else if(temp==13)
						  {
							  c.setModified_by(word[temp]);
							
						  }
						  
						  else if(temp==14)
						  {
							  c.setAuthorized_date(word[temp]);
							  
						  }
						  
						  else if(temp==15)
						  {
							  c.setAuthorized_by(word[temp]);
							  
						  }
						  
						  
				   }
				   
				   
				   
				   }
				   line=br.readLine();
				   al.add(c);
				   
				   }
				  
			   }
			   
			   
			   
			   catch(FileNotFoundException e)
			   {
				   e.printStackTrace();
			   }
			   
			   finally
			   {
				   br.close();
				   fr.close();
			   }
		
		
		
		
		return al;
		
		}
	}
	

