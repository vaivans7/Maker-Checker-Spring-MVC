package com.nucleus.Execute;

import java.util.ArrayList;

import com.DaoFactory.CustomerDaoFactory;
import com.nucleus.Connection.*;
import java.io.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import com.nucleus.Entity.*;
import com.nucleus.Execute.*;
import com.nucleus.Service.ServiceDaoImplementation;
import com.nucleus.dao.CustomerDao;
import com.nucleus.dao.CustomerRdbmsDaoImplementation;

public class Test {

	public static void main(String[]args)throws IOException,SQLException 
	{
		
		
		ArrayList<String> primary=new ArrayList<String>();
		
		ConnectionClass cc=new ConnectionClass();
		Connection con=cc.getDBConnection();
		
		
		Scanner sc=new Scanner(System.in);
		
		//ExecuteFile ef=new ExecuteFile();
		ExecuteFile ef=new ExecuteFile();
		//CustomerRdbmsDaoImplementation crdi=new CustomerRdbmsDaoImplementation();
		CustomerDaoFactory cdf=new CustomerDaoFactory();
		CustomerDao customerdao=cdf.getCustomerDaoObject("rdbms");
				
		ServiceDaoImplementation sdi=new ServiceDaoImplementation();
		ArrayList<Customer> al=new ArrayList<Customer>();
		
		System.out.println("Enter the file name");
		String name=sc.next();
		
		
	    al=ef.read(name);
	    
	   
	    
	    
	    
	    System.out.println("Enter the file reject permission 'F' For File Level and 'R' for Read Level");
	    char permission=sc.next().charAt(0);
	 
	    
	    int p=0;
	    int q=0;
		int flag=0;
		
	   for(int i=0;i<al.size();i++)
	    {
	    	
	    	
	    	
	    	if(permission=='R')
	    	{
	    		int value=sdi.validateReadLevel(al.get(i),i,primary);
	    		//System.out.println(value);
	    		
	    		if(value==-1)
	    		{
	    			customerdao.save(al.get(i),con);
	    			q++;
	    		}
	    		
	    		else if(value>=0)
	    		{
	    			
	    			
	    			
	    			
	    			
	    			p++;
	    		
	    			Customer c1=al.get(value);
	    			ArrayList<String> ai=sdi.printRecord(al.get(i),i,primary);
	    			
	    			//System.out.println(c1);
	    			sdi.FileEntry(c1,ai,i);
	    			
	    			
	    		}
	    		
	    	}
	    	
	    	else if(permission=='F')
	    	{
	    		int value=sdi.validateWriteLevel(al.get(i),i);
	    	
	    		if(value==-1)
	    		{
	    			flag++;
	    			q++;
	    		}
	    		
	    		else{
	    			System.out.println("Your File Rejected");
	    			System.exit(0);
	    		}
	    		
	    		
	    		if(flag==100)
	    		{
	    			for(Customer c:al)
	    			
	    			customerdao.save(c,con);
	    			
	    		}
	    		
	    		
	    		
	    	}
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    }
	    
	    
	    
	    
	    if(q>0 && q==100)
    	{
    		System.out.println("All Records Sucessfully Entered");
    		
    		
    	}
    	
    	else if(q>0 && q<100)
    	{
    		System.out.println(q+" Records Sucessfully Entered and "+p+" Records Failed");
    		System.out.println("Failed Records can be seen in errorlog.txt file");
    	}
    	
    	
    	
    	
    	if(q==0)
    		
    	{
    	    System.out.println("All Records can't be entered due to validation check failure...... refer file errorlog.txt");
    	}
	    
	    
	    
	    
	con.close();    
	    
	
	    
		
		
		
	}
	
	
	
}
