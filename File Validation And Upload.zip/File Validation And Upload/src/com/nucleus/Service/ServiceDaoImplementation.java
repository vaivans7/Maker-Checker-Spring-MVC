package com.nucleus.Service;
import com.nucleus.Entity.Customer;

import java.util.*;
import com.nucleus.validation.*;
import java.io.*;
public class ServiceDaoImplementation {

	
	Validation validation=new Validation();
	
	
	
	
	public int validateReadLevel(Customer c,int i,ArrayList<String>primary)
	{
		
	
		
		
		
		
		int temp=0;
		int temp1=-1;
		
		if(validation.dataLength(c.getCustomer_code(),10)
				&&validation.dataLength(c.getCustomer_name(),30)
				&&validation.dataLength(c.getCustomer_address1(),100)
				&&validation.dataLength(c.getCustomer_address2(),100)
				&&validation.datalength(c.getCustomer_pincode(),6)
				&&validation.dataLength(c.getEmail_address(),100)
				&&validation.datalength(c.getContact_number(),20)
				&&validation.dataLength(c.getContact_person(),100)
				&&validation.dataLength(c.getRecord_status(),1)
				&&validation.dataLength(c.getActive_inactive_flag(),1)
				&&validation.dataLength(c.getCreated_by(),30)
				&&validation.dataLength(c.getModified_by(),30)
				&&validation.dataLength(c.getAuthorized_by(),30))
		{
			temp=0;
			
		}
		
		else
		{
			temp++;
			temp1=i;
			
		}
		
		
		if(validation.dataType(c.getCustomer_code(),"string")
				&&validation.dataType(c.getCustomer_name(),"string")
				&&validation.dataType(c.getCustomer_address1(),"string")
				&&validation.dataType(c.getCustomer_address2(),"string")
				&&validation.datatype(c.getCustomer_pincode(), "Long")
				&&validation.dataType(c.getEmail_address(),"string")
				&&validation.datatype(c.getContact_number(), "Long")
				&&validation.dataType(c.getContact_person(),"string")
				&&validation.dataType(c.getRecord_status(),"string")
				&&validation.dataType(c.getActive_inactive_flag(),"string")
				&&validation.dataType(c.getCreated_by(),"string")
				&&validation.dataType(c.getModified_by(),"string")
				&&validation.dataType(c.getAuthorized_by(),"string"))
			
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		if(validation.mandatory(c.getCustomer_code(),'Y')
				&&validation.mandatory(c.getCustomer_name(),'Y')
				&&validation.mandatory(c.getCustomer_address1(),'Y')
				&&validation.mandatory(c.getCustomer_address2(),'N')
				&&validation.mandatory(c.getCustomer_pincode(),'Y')
				&&validation.mandatory(c.getEmail_address(),'Y')
				&&validation.mandatory(c.getContact_number(),'N')
				&&validation.mandatory(c.getContact_person(),'Y')
				&&validation.mandatory(c.getRecord_status(),'Y')
				&&validation.mandatory(c.getActive_inactive_flag(),'N')
				&&validation.mandatory(c.getCreated_by(),'N')
				&&validation.mandatory(c.getModified_by(),'N')
				&&validation.mandatory(c.getAuthorized_by(),'N'))
		
				
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		
		
		if(validation.isalpha(c.getCustomer_name()))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		if(validation.emailValidation(c.getEmail_address()))
		{
			temp=0;
		}
		
		else
		{
			temp++;
			temp1=i;
		}
	
		
		//return temp1;
		
		
		String check[]=new String[]{"N","M","D","R","A"};
		
		if(validation.domainValue(c.getRecord_status(),check))
		{
			temp=0;
		}
		
		
		else{
			temp++;
			temp1=i;
		}
		
		
		String check1[]=new String[]{"A","I"};
		
		if(validation.domainValue(c.getActive_inactive_flag(),check1))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		
		
		
		
	//	al=null;
		
		/*
		if(temp==0)
		{
			return 0;
		}
		
		else
		{
			return temp1;
		}
		*/
		
		
	/*
		
		if(validation.primarykey_check(al,c.getCustomer_code()))
		{
			al.add(c.getCustomer_code());
			
		}
		
		else
		{
			temp1=i;
		}
		
		
		*/
		return temp1;
		
		
	
	}
	
	
	public int validateWriteLevel(Customer c,int i)
	{
		
		int temp=0;
		int temp1=-1;
		
		if(validation.dataLength(c.getCustomer_code(),10)
				&&validation.dataLength(c.getCustomer_name(),30)
				&&validation.dataLength(c.getCustomer_address1(),100)
				&&validation.dataLength(c.getCustomer_address2(),100)
				&&validation.datalength(c.getCustomer_pincode(),6)
				&&validation.dataLength(c.getEmail_address(),100)
				&&validation.datalength(c.getContact_number(),20)
				&&validation.dataLength(c.getContact_person(),100)
				&&validation.dataLength(c.getRecord_status(),1)
				&&validation.dataLength(c.getActive_inactive_flag(),1)
				&&validation.dataLength(c.getCreated_by(),30)
				&&validation.dataLength(c.getModified_by(),30)
				&&validation.dataLength(c.getAuthorized_by(),30))
		{
			temp=0;
			
		}
		
		else
		{
			temp++;
			temp1=i;
			
		}
		
		
		if(validation.dataType(c.getCustomer_code(),"string")
				&&validation.dataType(c.getCustomer_name(),"string")
				&&validation.dataType(c.getCustomer_address1(),"string")
				&&validation.dataType(c.getCustomer_address2(),"string")
				&&validation.dataType(c.getCustomer_pincode(),"string")
				&&validation.dataType(c.getEmail_address(),"string")
				&&validation.dataType(c.getContact_number(),"string")
				&&validation.dataType(c.getContact_person(),"string")
				&&validation.dataType(c.getRecord_status(),"string")
				&&validation.dataType(c.getActive_inactive_flag(),"string")
				&&validation.dataType(c.getCreated_by(),"string")
				&&validation.dataType(c.getModified_by(),"string")
				&&validation.dataType(c.getAuthorized_by(),"string"))
			
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		if(validation.mandatory(c.getCustomer_code(),'Y')
				&&validation.mandatory(c.getCustomer_name(),'Y')
				&&validation.mandatory(c.getCustomer_address1(),'Y')
				&&validation.mandatory(c.getCustomer_address2(),'N')
				&&validation.mandatory(c.getCustomer_pincode(),'Y')
				&&validation.mandatory(c.getEmail_address(),'Y')
				&&validation.mandatory(c.getContact_number(),'N')
				&&validation.mandatory(c.getContact_person(),'Y')
				&&validation.mandatory(c.getRecord_status(),'Y')
				&&validation.mandatory(c.getActive_inactive_flag(),'N')
				&&validation.mandatory(c.getCreated_by(),'N')
				&&validation.mandatory(c.getModified_by(),'N')
				&&validation.mandatory(c.getAuthorized_by(),'N'))
		
				
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		
		
		if(validation.isalpha(c.getCustomer_name()))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		if(validation.emailValidation(c.getEmail_address()))
		{
			temp=0;
		}
		
		else
		{
			temp++;
			temp1=i;
		}
	
		
		//return temp1;
		
		
		String check[]=new String[]{"N","M","D","R","A"};
		
		if(validation.domainValue(c.getRecord_status(),check))
		{
			temp=0;
		}
		
		
		else{
			temp++;
			temp1=i;
		}
		
		
		String check1[]=new String[]{"A","I"};
		
		if(validation.domainValue(c.getActive_inactive_flag(),check1))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			temp1=i;
		}
		
		
		
		
		
		
		/*
		if(temp==0)
		{
			return 0;
		}
		
		else
		{
			return temp1;
		}
		*/
		return temp1;
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	public void FileEntry(Customer c,ArrayList<String> ai,int i)throws IOException
	{
		
		String str=c.getCustomer_code()+"~"+c.getCustomer_name()+"~"+c.getCustomer_address1()+"~"+c.getCustomer_address2()+"~"+c.getCustomer_pincode()+"~"+c.getEmail_address()+"~"+c.getContact_number()+"~"+c.getContact_person()+"~"+c.getRecord_status()+"~"+c.getActive_inactive_flag()+"~"+c.getCreate_date()+"~"+c.getCreated_by()+"~"+c.getModified_date()+"~"+c.getModified_by()+"~"+c.getAuthorized_date()+"~"+c.getAuthorized_by();
		
		
		StringBuilder sb=new StringBuilder("Error Due to following Validation Failures:[");
		
		
		for(int j=0;j<ai.size();j++)
		{
			sb.append(ai.get(j));
			sb.append(",");
			
			
		}
		
		sb.append("]");
		String str1=sb.toString();	
		
		
			FileWriter fr=new FileWriter("C:\\Users\\Temp\\Desktop\\errorlog.txt",true);
			BufferedWriter br=new BufferedWriter(fr);
			
			br.write(str1);
			br.newLine();
			
		br.write(str);
		br.newLine();
		
		br.write("-----------------------------------------------------------------------------------------------------------------------------------");
		br.newLine();
		
		
		br.close();
		fr.close();
		
		
		
		
	}
	
	
	
	/*-------------------------------------------------------------------------------------------------------*/
	
	
	
	public ArrayList<String> printRecord(Customer c,int i,ArrayList<String>primary)
	{
		
		
		
		
		ArrayList<String> ai=new ArrayList<>();
		
		
		
		int temp=0;
		int temp1=-1;
		
		if(validation.dataLength(c.getCustomer_code(),10)
				&&validation.dataLength(c.getCustomer_name(),30)
				&&validation.dataLength(c.getCustomer_address1(),100)
				&&validation.dataLength(c.getCustomer_address2(),100)
				&&validation.datalength(c.getCustomer_pincode(),6)
				&&validation.dataLength(c.getEmail_address(),100)
				&&validation.datalength(c.getContact_number(),20)
				&&validation.dataLength(c.getContact_person(),100)
				&&validation.dataLength(c.getRecord_status(),1)
				&&validation.dataLength(c.getActive_inactive_flag(),1)
				&&validation.dataLength(c.getCreated_by(),30)
				&&validation.dataLength(c.getModified_by(),30)
				&&validation.dataLength(c.getAuthorized_by(),30))
		{
			temp=0;
			
		}
		
		else
		{
			temp++;
			ai.add("Data Length");
			temp1=i;
			
		}
		
		
		if(validation.dataType(c.getCustomer_code(),"string")
				&&validation.dataType(c.getCustomer_name(),"string")
				&&validation.dataType(c.getCustomer_address1(),"string")
				&&validation.dataType(c.getCustomer_address2(),"string")
				&&validation.datatype(c.getCustomer_pincode(), "Long")
				&&validation.dataType(c.getEmail_address(),"string")
				&&validation.datatype(c.getContact_number(), "Long")
				&&validation.dataType(c.getContact_person(),"string")
				&&validation.dataType(c.getRecord_status(),"string")
				&&validation.dataType(c.getActive_inactive_flag(),"string")
				&&validation.dataType(c.getCreated_by(),"string")
				&&validation.dataType(c.getModified_by(),"string")
				&&validation.dataType(c.getAuthorized_by(),"string"))
			
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			ai.add("Data Type");
			temp1=i;
		}
		
		
		if(validation.mandatory(c.getCustomer_code(),'Y')
				&&validation.mandatory(c.getCustomer_name(),'Y')
				&&validation.mandatory(c.getCustomer_address1(),'Y')
				&&validation.mandatory(c.getCustomer_address2(),'N')
				&&validation.mandatory(c.getCustomer_pincode(),'Y')
				&&validation.mandatory(c.getEmail_address(),'Y')
				&&validation.mandatory(c.getContact_number(),'N')
				&&validation.mandatory(c.getContact_person(),'Y')
				&&validation.mandatory(c.getRecord_status(),'Y')
				&&validation.mandatory(c.getActive_inactive_flag(),'N')
				&&validation.mandatory(c.getCreated_by(),'N')
				&&validation.mandatory(c.getModified_by(),'N')
				&&validation.mandatory(c.getAuthorized_by(),'N'))
		
				
		{
			temp=0;
			
		}
		
		
		else
		{
			temp++;
			ai.add("Mandatory Check");
			temp1=i;
		}
		
		
		
		
		
		if(validation.isalpha(c.getCustomer_name()))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			ai.add("Alpha Failure");
			temp1=i;
		}
		
		
		
		if(validation.emailValidation(c.getEmail_address()))
		{
			temp=0;
		}
		
		else
		{
			temp++;
			ai.add("Email Validation");
			temp1=i;
		}
	
		
		//return temp1;
		
		
		String check[]=new String[]{"N","M","D","R","A"};
		
		if(validation.domainValue(c.getRecord_status(),check))
		{
			temp=0;
		}
		
		
		else{
			temp++;
			ai.add("Record Status Failure");
			temp1=i;
		}
		
		
		String check1[]=new String[]{"A","I"};
		
		if(validation.domainValue(c.getActive_inactive_flag(),check1))
		{
			temp=0;
		}
		
		
		else
		{
			temp++;
			ai.add("Active Inactive Failure");
			temp1=i;
		}
		
		
		/*
		if(validation.primarykey_check(a2,c.getCustomer_code()))
		{
			a2.add(c.getCustomer_code());
			
		}
		
		else
		{
			//temp1=i;
			ai.add("Primary Key");
		}
		
		*/
		
		
		
		
	
		
		
		/*
		if(validation.primary_check(al,c.getCustomer_code()))
		{
			temp++;
			ai.add("Primary Key Failure");
			temp1=i;
		}
		
		else{
			
			al.add(c.getCustomer_code());
		}
		
		
		
		al=null;
		*/
		
	 return ai;
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
