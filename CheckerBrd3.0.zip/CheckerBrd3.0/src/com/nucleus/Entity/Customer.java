package com.nucleus.Entity;

import java.util.*;

public class Customer {

	
	private String customer_code;
	private String customer_name;
	private String customer_address1;
	private String customer_address2;
	private long customer_pincode;
	private String email_address;
	private long contact_number;
	private String contact_person;
	private String record_status;
	private String active_inactive_flag;
	private Date create_date;
	private String created_by;
	private Date modified_date;
	private String modified_by;
	private Date authorized_date;
	private String authorized_by;
	private String gender;
	
	
	
	
	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	@Override
	public String toString() {
		return "Customer [customer_code=" + customer_code + ", customer_name=" + customer_name + ", customer_address1="
				+ customer_address1 + ", customer_address2=" + customer_address2 + ", customer_pincode="
				+ customer_pincode + ", email_address=" + email_address + ", contact_number=" + contact_number
				+ ", contact_person=" + contact_person + ", record_status=" + record_status + ", active_inactive_flag="
				+ active_inactive_flag + ", create_date=" + create_date + ", created_by=" + created_by
				+ ", modified_date=" + modified_date + ", modified_by=" + modified_by + ", authorized_date="
				+ authorized_date + ", authorized_by=" + authorized_by + "]";
	}
	
	
	
	
	public String getCustomer_code() {
		return customer_code;
	}
	public void setCustomer_code(String customer_code) {
		this.customer_code = customer_code;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_address1() {
		return customer_address1;
	}
	public void setCustomer_address1(String customer_address1) {
		this.customer_address1 = customer_address1;
	}
	public String getCustomer_address2() {
		return customer_address2;
	}
	public void setCustomer_address2(String customer_address2) {
		this.customer_address2 = customer_address2;
	}
	public long getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(long customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getRecord_status() {
		return record_status;
	}
	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
	public String getActive_inactive_flag() {
		return active_inactive_flag;
	}
	public void setActive_inactive_flag(String active_inactive_flag) {
		this.active_inactive_flag = active_inactive_flag;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getAuthorized_date() {
		return authorized_date;
	}
	public void setAuthorized_date(Date authorized_date) {
		this.authorized_date = authorized_date;
	}
	public String getAuthorized_by() {
		return authorized_by;
	}
	public void setAuthorized_by(String authorized_by) {
		this.authorized_by = authorized_by;
	}
	
	
	
	
	
}