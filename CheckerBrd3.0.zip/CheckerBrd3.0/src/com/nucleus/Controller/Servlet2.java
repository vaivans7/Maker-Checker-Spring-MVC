package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.Dao.UserDaoRDBMS;
import com.nucleus.Entity.User;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Servlet2() {
        super();
       
    }
    User user;
    
    void userlogin(HttpServletRequest request, HttpServletResponse response)
    {
    	

    	
    	
    		
    			
    			UserDaoRDBMS userdao=new UserDaoRDBMS();
    	    	
    	    	
    	    	try {
    			
    				String id=request.getParameter("uid");
    				String password=request.getParameter("password");
    				String logout=request.getParameter("uname");
    				
    			
    				
    				
    				user=userdao.retrive(id,password);
    				
    				
    			  if(user!=null)
    			  {
    				  
    			  
    				int flag=userdao.getFlag(id, password);
    				
    				
    				if(flag==0)
    				{
    				String role=user.getUserRole();
    				
    				
    				
    				HttpSession session=request.getSession();
    				session.setAttribute("user",user);
    				
    				ServletContext context=getServletContext();
    				context.setAttribute(session.getId(),"mysession");
    				
    				
    				userdao.setFlag(id, password, 1);
    				userdao.setUserSession(id, password, session.getId());
    				
    				
    				
    				
    				
    				if(role.equals("M"))
    				{
    					response.sendRedirect("first.jsp");
    				}
    				
    				
    				else if(role.equals("C"))
    				{
    					response.sendRedirect("checkerfirst.jsp");
    				}
    				
    			  }
    			  
    			  else
    			  {
    				  response.sendRedirect("User.html");
    				  
    			  }
    				
    				
    			  }	
    			  
    			  else
    			  {
    				  response.sendRedirect("User.html");
    			  }
    				
    				
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	
    	    	
    			
    			
    			
    
    	
    	
    	
    }
    
    
    
    void userlogout(HttpServletRequest request, HttpServletResponse response)
    {
    	
    	UserDaoRDBMS udr=new UserDaoRDBMS();
		HttpSession session=request.getSession(false);
		User user=(User)session.getAttribute("user");
		
		udr.setFlag(user.getUserId(),user.getUserPassword(),0);
		udr.setUserSession(user.getUserId(), user.getUserPassword(), null);
		
		
		session.invalidate();
		
		try {
			response.sendRedirect("index.html");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	
    	
    	
    }
    
    
    
    
    
    
    void process(HttpServletRequest request, HttpServletResponse response)
    
    {
    	
   
    	
    	
    	PrintWriter out=null;
    	try{
    	 out=response.getWriter();
    	}
    	catch(IOException e)
    	{
    		e.printStackTrace();
    	}
    	String crud=request.getParameter("crud");
    	
    	
    	
    	
    	
    	//out.println(crud);
    	//request.setAttribute("action",crud);
    	
    	if(crud!=null)
    	{
    	
    	if(crud.equals("create"))
    	{
    		try{
    			
    	   // RequestDispatcher rd=new RequestDispatcher("Customer");

                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache"); // HTTP 1.0
               response.setDateHeader("Expires", 0); // Proxies.
    			
    		response.sendRedirect("Customer.jsp");
    			
    		}
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	
    	
    	
    	
    	if(crud.equals("retrive"))
    	{
    		try{
    		response.sendRedirect("retrive1.jsp");
    		}
    		
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	
    	if(crud.equals("retriveall"))
    	{
    		
    		try{
        		
    			
    			request.setAttribute("all",crud);
    			RequestDispatcher rd=request.getRequestDispatcher("Servlet3");
    			
    			rd.forward(request,response);
    			
    			
    			
    			
    			
        		}
        		
        		catch(ServletException | IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    	}
    	
    	
    	
    	
    	

    	if(crud.equals("update"))
    	{
    		
    		try{
    			
        		
    			
    			response.sendRedirect("update.jsp");
    			
    			
    			
    			
    			
        		}
        		
        		catch(IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    	}
    	
    	
    	
    	if(crud.equals("delete"))
    	{
    		try{
    		response.sendRedirect("delete.jsp");
    		}
    		
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	//------   Modify Authorize Record-------
    	
    	if(crud.equals("modifyauthorizerecord"))
    	{
    		
try{
	    
    			
    			request.setAttribute("modifyauthorizerecord",crud);
    			RequestDispatcher rd=request.getRequestDispatcher("Servlet3");
    			
    			rd.forward(request,response);
    			
    			
    			
    			
    			
        		}
        		
        		catch(ServletException | IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    	}
    	
    	
    	if(crud.equals("deleteauthorizerecord"))
    	{
    		
try{
	    
    			
    			request.setAttribute("deleteauthorizerecord",crud);
    			RequestDispatcher rd=request.getRequestDispatcher("Servlet3");
    			
    			rd.forward(request,response);
    			
    			
    			
    			
    			
        		}
        		
        		catch(ServletException | IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    		
    	}
    	
    	
    	
    	
    	
    	}
    	
    }
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	
		
   // HttpSession session=request.getSession(false);
    
 
    
  
   // User user=(User)session.getAttribute("user");
	
		process(request,response);
		
		
	/*
		if(user!=null)	
		
	{
		process(request,response);
	}
	else
	{
		response.sendRedirect("index.html");
		
	}
	
	*/
	
	String logout=request.getParameter("uname");
	
	if(logout!=null)
	{
		if(logout.equals("logout"))
		{
			userlogout(request,response);
		}
	}
	
	
	
    	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		userlogin(request,response);
	
	}

}