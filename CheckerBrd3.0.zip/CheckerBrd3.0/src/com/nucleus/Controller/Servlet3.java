package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.Dao.CheckerDaoRDBMS;
import com.nucleus.Dao.UserDaoRDBMS;
import com.nucleus.Entity.Customer;
import com.nucleus.Entity.User;
import com.nucleus.Service.ServiceDaoImplementation;

import java.util.*;

@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Servlet3() {
        super();
       
    }

    
    Customer finalcustomer;
    
    
    void process(HttpServletRequest request, HttpServletResponse response)
    {
    	
    	
    	
    	PrintWriter out=null;
    	try {
		    out=response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	String name=request.getParameter("create");
    	String name1=request.getParameter("retrive");
    	
    	String name2=(String)request.getAttribute("all");
    	
    	String name3=request.getParameter("update");
    	String name4=request.getParameter("newupdate");
    	
    	String name5=request.getParameter("delete");
    	
    	String name6=request.getParameter("retrivebyorder");
    	
    	String name7=(String)request.getAttribute("modifyauthorizerecord");
    	
    	String name8=request.getParameter("newauthorizeupdate");
    	
    	
    	String name9=(String)request.getAttribute("deleteauthorizerecord");
    	
    	
    	
    	
    	
/*Enumeration<String> params1 = request.getParameterNames();
    	
    	//--Fetching Authorized Record for Deletion
    	
    	if(params1!=null)
    	{
    		 String paramName = params1.nextElement();
 			String value=request.getParameter(paramName);
    		
 			if(value.equals("Delete"))
 			{
    		
    		CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    		
    		Customer customer=cdr.retrive(paramName);
    		//System.out.println(customer);
    		
    	
    		customer.setRecord_status("D");
    		
    		UserDaoRDBMS udr=new UserDaoRDBMS();
    		
    		boolean flag=udr.save(customer,"deleteauthorize");
    		
    		if(flag==true)
    		{
    			request.setAttribute("status","Record Status Set as Deleted needs to be approved by Checker..");
    			
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    		else if(flag==false)
    		{
request.setAttribute("status","Record Delete Failed..");
    			
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    		
 			}
    		
    		
    	}*/
    	
    	
    	
    	
    	
    	
    	
    	if(name9!=null)
    	{
    		
    		if(name9.equals("deleteauthorizerecord"))
    			
    		{
CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    			
    			ArrayList<Customer> alist=cdr.retriveAll();
    			
    			
    			
    			
    			request.setAttribute("mylist",alist);
    			
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    			
    		}
    		
    		
    		
    	}
    	
    	
    	
    	
    	
    	if(name8!=null)
    	{
    		
    		if(name8.equals("New Authorize Update"))
    			
    		{
    			
    			
    			HttpSession session=request.getSession();
    			User user=(User)session.getAttribute("user");
    			
	           Customer customer=new Customer();
    			
    			String customer_code=request.getParameter("customerCode");
    			String customer_name=request.getParameter("customerName");
    			String customer_address1=request.getParameter("address1");
    			String customer_address2=request.getParameter("address2");
    			String customer_pincode=request.getParameter("customerPinCode");
    			String customer_email=request.getParameter("emailAddress");
    			String contact_number=request.getParameter("contactNumber");
    			String contact_person=request.getParameter("contactPerson");
    			String active_inactive_flag=request.getParameter("aIFlag");
    			
    			
    			CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    			
    		
    			Customer customer1=cdr.retrive(customer_code);
    		
    			
    			Long pincode=Long.parseLong(customer_pincode);
    			Long number=Long.parseLong(contact_number);
    			
    			java.util.Date date=new java.util.Date();
    			
    			
    			customer.setCustomer_code(customer_code.trim());
    			customer.setCustomer_name(customer_name);
    			customer.setCustomer_address1(customer_address1);
    			customer.setCustomer_address2(customer_address2);
    			customer.setCustomer_pincode(pincode);
    			customer.setEmail_address(customer_email);
    			customer.setContact_number(number);
    			customer.setContact_person(contact_person);
    			customer.setActive_inactive_flag(active_inactive_flag);
    			customer.setRecord_status("M");
    			customer.setCreate_date(customer1.getCreate_date());
    			customer.setCreated_by(customer1.getCreated_by());
    			customer.setModified_date(date);
    			customer.setModified_by(user.getUserId());
    			customer.setAuthorized_date(customer1.getAuthorized_date());
    			customer.setAuthorized_by(customer1.getAuthorized_by());
    			
    			/*------Check if record exists in temporary table before saving it------*/
    			
    			UserDaoRDBMS udr=new UserDaoRDBMS();
    			
    			
    			Customer customer2=udr.retrive(customer_code.trim());
    			
    			
    			if(customer2==null) {
    			boolean flag=udr.save(customer,"modifyapprove");
    			
    			
    			if(flag==true)
    			{
    				request.setAttribute("status","Approve Record Update Success..");
    				RequestDispatcher rd=request.getRequestDispatcher("modifyauthorizerecord2.jsp");
    				try {
						rd.forward(request,response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				
    				
    			}
    			
    			else
    			{
    				request.setAttribute("status","Approve Record Update Failed");
    				RequestDispatcher rd=request.getRequestDispatcher("modifyauthorizerecord2.jsp");
    				try {
						rd.forward(request,response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			}
    			
    		}
    		
    			
    			else {
    				
    				
    				String record_status=customer2.getRecord_status();
    				String message="Record Already Pending for Approval with status: "+record_status+" Cannot be Updated";
    				request.setAttribute("status",message);
    				RequestDispatcher rd=request.getRequestDispatcher("modifyauthorizerecord2.jsp");
    				try {
						rd.forward(request,response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				
    				
    				
    				
    			}
    			
    		
    		
    	}
    	
    	
    	}
    	
    	
    	//String name8=request.getParameter("someKeyName");
    	
    	//System.out.println(name8);
    	
    	Enumeration<String> params = request.getParameterNames(); 
    	
    	//--Fetching Authorized Record for modification
    	
    	if(params!=null)
    	{
    		 String paramName = params.nextElement();
 			String value=request.getParameter(paramName);
    		
 			if(value.equals("Modify"))
 			{
    		
 				System.out.println("modify");
    		CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    		
    		Customer customer=cdr.retrive(paramName);
    		System.out.println(customer);
    		
    		request.setAttribute("myobject",customer);
    		
    		RequestDispatcher rd=request.getRequestDispatcher("modifyauthorizerecord2.jsp");
    		
    		try {
				rd.forward(request,response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
 			}
    		
    		
    	
    	
    	
    	else if(value.equals("Delete"))
    	{
    		System.out.println("mydelete");
CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    		
    		Customer customer=cdr.retrive(paramName);
    		System.out.println("deleteauthorize "+customer);
    		
    	
    		customer.setRecord_status("D");
    		System.out.println("deleteauthorize2 "+customer);
    		UserDaoRDBMS udr=new UserDaoRDBMS();
    		
    		Customer customer2=udr.retrive(customer.getCustomer_code().trim());
    		
    		
    		if(customer2==null)
    		{
    		
    		boolean flag=udr.save(customer,"deleteauthorize");
    		
    		if(flag==true)
    		{
    			request.setAttribute("status","Record Status Set as Deleted needs to be approved by Checker..");
    			
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord1.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    		else if(flag==false)
    		{
request.setAttribute("status","Record Delete Failed..");
    			
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord1.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    		
    		
    	}
    		
    		else
    		{
    		
    			String record_status=customer2.getRecord_status();
    			request.setAttribute("status","Record Pending for Approval with Status: "+record_status+" Cannot Delete");
    			RequestDispatcher rd=request.getRequestDispatcher("deleteauthorizerecord1.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    	
    	
    	}
    	
    	
    	}
    	
    	
    	
    	//-------Modify new Record-------
    	
    	if(name7!=null)
    	{
    		
    		if(name7.equals("modifyauthorizerecord"))
    		{
    			
    		
    			
    			CheckerDaoRDBMS cdr=new CheckerDaoRDBMS();
    			
    			ArrayList<Customer> alist=cdr.retriveAll();
    			
    			System.out.println(alist);
    			System.out.println("hello");
    			
    			request.setAttribute("mylist",alist);
    			
    			RequestDispatcher rd=request.getRequestDispatcher("modifyauthorizerecord.jsp");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    			
    		}
    		
    		
    		
    	}
    	
    	
    	
    	
    	
    	
    	System.out.println(name2);
    	
    	if(name!=null)
    	{
    	
    	if(name.equals("Create"))
    	{
    	
    	String customer_code=request.getParameter("customercode");
    	String customer_name=request.getParameter("customername");
    	String customer_address1=request.getParameter("address1");
    	String customer_address2=request.getParameter("address2");
    	String pincode=request.getParameter("pincode");
    	String email=request.getParameter("email");
    	String contact_number=request.getParameter("number");
    	String primary_contact_person=request.getParameter("person");
    	String record_status=request.getParameter("status");
    	
    	
    	Customer customer=new Customer();
    	ServiceDaoImplementation sdi=new ServiceDaoImplementation();
    	
    	
    	
    java.util.Date date=new java.util.Date();
    System.out.println(date);
    
    
    	
    	
    	HttpSession session=request.getSession();
    	//out.println(date);
    	User user=(User)session.getAttribute("user");
    	String createby=user.getUserId();
    	
    	
    	long pincode1=Long.parseLong(pincode);
    	long number1=Long.parseLong(contact_number);
    	
    	customer.setCustomer_code(customer_code);
    	customer.setCustomer_name(customer_name);
    	customer.setCustomer_address1(customer_address1);
    	customer.setCustomer_address2(customer_address2);
    	customer.setCustomer_pincode(pincode1);
    	customer.setEmail_address(email);
    	
    	customer.setContact_number(number1);
    	customer.setContact_person(primary_contact_person);
    	customer.setActive_inactive_flag(record_status);
    	customer.setRecord_status("N");
    	customer.setCreate_date(date);
    	customer.setCreated_by(createby);
    	customer.setModified_date(null);
    	customer.setModified_by("");
    	customer.setAuthorized_date(null);
    	customer.setAuthorized_by("");
    	
    	
    	UserDaoRDBMS udr=new UserDaoRDBMS();
    	
    
    	int temp=sdi.validateReadLevel(customer);
    	
   
    	
    	
    	if(temp==0)
    	{
    		
    		boolean flag=udr.save(customer);
    		System.out.println(flag);
    		
    		
    			request.setAttribute("status","Record Taken Successfully");
    			
    			RequestDispatcher rd=request.getRequestDispatcher("Customer.jsp");
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		
    		
    	
    		
    	}
    	
    	
    	
    	
    	
    	else if(temp>0)
    	{
    		request.setAttribute("status","Record Failed");
			
			RequestDispatcher rd=request.getRequestDispatcher("Customer.jsp");
			try {
				rd.forward(request,response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	
    	
    	
    	System.out.println(temp);
    	
    	
    	
    	
    	}
    	
    	}
    	
    	
    	
    	if(name1!=null)
    	{
    	
    	if(name1.equals("Retrive"))
    	{
    
    		String id=request.getParameter("uid");
    		Customer customer=null;
        	ServiceDaoImplementation sdi=new ServiceDaoImplementation();
        	UserDaoRDBMS udr=new UserDaoRDBMS();
        	System.out.println(id);
        	customer=udr.retrive(id);
        	
        	
        	
        	request.setAttribute("retrive",customer);
        	
    try{
        		RequestDispatcher rd=request.getRequestDispatcher("retrive1.jsp");
        		rd.forward(request,response);
        
    }
    
    catch(ServletException | IOException e)
    {
    	e.printStackTrace();
    }
        	
    		
    	}
    	
    	
    	}
    	
    	
    	
    	
    	if(name2!=null)
    	{
    		
    		if(name2.equals("retriveall"))
    		{
    			
    			try {
					response.sendRedirect("retriveall.jsp");
				} catch (IOException e) {
					e.printStackTrace();
					e.printStackTrace();
				}
    			
    		}
    		
    	}
    	
    	
    	
    	
    	
    	
    	if(name6!=null)
    	{
    		String order=request.getParameter("orderby");
    		String sort=request.getParameter("sort");
    		
    		System.out.println(order);
    		System.out.println(order.length());
    		System.out.println(sort);
    		
    		
    		if(order.equals("customer_id")||order.equals("customer_code")||order.equals("custome_name")||order.equals("customer_address1"))
    		{
    			
    			
    			ArrayList<Customer>alist=null;
    			
    			UserDaoRDBMS udr=new UserDaoRDBMS();
    			alist=udr.retriveAll(order,sort);
    			
    			
    			
    			
    			
    			request.setAttribute("mylist",alist);
    			
    			try
    			{
    				RequestDispatcher rd=request.getRequestDispatcher("retriveall.jsp");
    				rd.forward(request,response);
    			}
    			
    			
    			catch(ServletException |IOException e)
    			{
    				e.printStackTrace();
    			}
    			
    			
    			
    			
    		}
    		
    		
    	}
    	
    	
    	
    	if(name3!=null)
    	{
    		
    		if(name3.equals("Proceed"))
    		{
    			
    			Customer customer=null;
    			UserDaoRDBMS udr=new UserDaoRDBMS();
    			
    			String id=request.getParameter("id");
    			customer=udr.retrive(id);
    			
    			finalcustomer=customer;
    			
    			request.setAttribute("customerobject",customer);
    			
    			try
    			{
    				RequestDispatcher rd=request.getRequestDispatcher("update2.jsp");
    				rd.forward(request,response);
    			}
    			
    			
    			catch(ServletException |IOException e)
    			{
    				e.printStackTrace();
    			}
    			
    			
    			
    			
    		}
    		
    		
    	}
    	
    	
    	
    	

    	if(name4!=null)
    	{
    		
    		if(name4.equals("UPDATE"))
    		{
    			
    			
    		java.util.Date date=new java.util.Date();
    		
    	    	
    	    	HttpSession session=request.getSession();
    	    	
    	    	User user=(User)session.getAttribute("user");
    	    	String modified_by=user.getUserId();
    	    	
    			Customer customer=new Customer();
    			
    			String customer_code=request.getParameter("customerCode");
    			String customer_name=request.getParameter("customerName");
    			String customer_address1=request.getParameter("address1");
    			String customer_address2=request.getParameter("address2");
    			String customer_pincode=request.getParameter("customerPinCode");
    			String customer_email=request.getParameter("emailAddress");
    			String contact_number=request.getParameter("contactNumber");
    			String contact_person=request.getParameter("contactPerson");
    			String active_inactive_flag=request.getParameter("aIFlag");
    			
    			customer.setCustomer_code(customer_code);
    			customer.setCustomer_name(customer_name);
    			customer.setCustomer_address1(customer_address1);
    			customer.setCustomer_address2(customer_address2);
    			customer.setCustomer_pincode(Long.parseLong(customer_pincode));
    			customer.setEmail_address(customer_email);
    			
    			
    			//customer.setCustomer_code(finalcustomer.getCustomer_code());
    			//customer.setCustomer_name(finalcustomer.getCustomer_name());
    			//customer.setCustomer_address1(finalcustomer.getCustomer_address1());
    			//customer.setCustomer_address2(finalcustomer.getCustomer_address2());
    			//customer.setCustomer_pincode(finalcustomer.getCustomer_pincode());
    			//customer.setEmail_address(finalcustomer.getEmail_address());
    			
    			//customer.setContact_number(Long.parseLong(contact_number));
    			customer.setContact_number(finalcustomer.getContact_number());
    			customer.setContact_person(contact_person);
    		customer.setActive_inactive_flag(active_inactive_flag);
    			
    		//customer.setContact_number(finalcustomer.getContact_number());
    			//customer.setContact_person(finalcustomer.getContact_person());
    			//customer.setActive_inactive_flag(finalcustomer.getActive_inactive_flag());
    			customer.setRecord_status("N");
    	    	customer.setCreate_date(finalcustomer.getCreate_date());
    	    	customer.setCreated_by(finalcustomer.getCreated_by());
    	    	customer.setModified_date(date);
    	    	customer.setModified_by(modified_by);
    	    	customer.setAuthorized_date(finalcustomer.getAuthorized_date());
    	    	customer.setAuthorized_by(finalcustomer.getAuthorized_by());
    			
    			
    			
    			
    			
    			
    			ServiceDaoImplementation sdi=new ServiceDaoImplementation();
    			
    			UserDaoRDBMS udr=new UserDaoRDBMS();
    	    	
    		    
    	    	//int temp=sdi.validateReadLevel(customer);
    	    	
    		//System.out.println(customer);
    			
    			boolean flag=udr.Update(customer);
    			
    			if(flag==true)
    			{
    				
    				request.setAttribute("status","Record Sucessfully Updated");
    				
    				RequestDispatcher rd=request.getRequestDispatcher("update2.jsp");
    				try{
    				rd.forward(request,response);
    				}
    				catch(ServletException | IOException e)
    				{
    					e.printStackTrace();
    				}
    				
    			}
    			else
    			{
    				
                    request.setAttribute("status","Record Updation Failed");
    				
    				RequestDispatcher rd=request.getRequestDispatcher("update2.jsp");
    				try{
    				rd.forward(request,response);
    				}
    				catch(ServletException | IOException e)
    				{
    					e.printStackTrace();
    				}
    			}
    	   
    			
    			
    			
    			/*
    	    	int temp=0;
    	    	
    	    	if(temp==0)
    	    	{
    	    		
    	    		boolean flag=udr.Update(customer);
    	    		if(flag==true)
    	    		{
    	    			out.println("Updated....");
    	    		}
    	    		
    	    		else{
    	    			out.println("Not Updated....");
    	    		}
    	    		
    	    	}
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	else if(temp==1)
    	    	{
    	    		out.print("Records Not Validated....");
    	    	}
    	    	
    			
    			*/
    			
    			
    			
    			
    			
    			
    			
    			
    			try
    			{
    				RequestDispatcher rd=request.getRequestDispatcher("update2.jsp");
    				rd.forward(request,response);
    			}
    			
    			
    			catch(ServletException |IOException e)
    			{
    				e.printStackTrace();
    			}
    			
    			
    			
    			
    		}
    		
    		
    	}
    	
    	
    	
    	if(name5!=null)
    	{
    		
    		if(name5.equals("Delete"))
    		{
    			
    			String id=request.getParameter("uid");
    			
    			UserDaoRDBMS udr=new UserDaoRDBMS();
    			
    			boolean flag=udr.delete(id);
    			
    			if(flag==true)
    			{
    				request.setAttribute("status","Record Successfully Deleted");
    				
    				RequestDispatcher rd=request.getRequestDispatcher("delete.jsp");
    				try {
						rd.forward(request,response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			}
    			
    			else
    			{
    				
                   request.setAttribute("status","Record Cannot be Deleted");
    				
    				RequestDispatcher rd=request.getRequestDispatcher("delete.jsp");
    				try {
						rd.forward(request,response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				
    				
    			}
    			
    			
    			
    			
    			
    		}
    		
    		
    		
    		
    	}
    	
    	
    	
    	
    	
    }
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//HttpSession session=request.getSession(false);
	    
	   // ServletContext context=getServletContext();
	   // String name=(String)context.getAttribute(session.getId());
	    
		process(request,response);
		
		
		/*User user=(User)session.getAttribute("user");
		
		if(user!=null)	
			
		{
			process(request,response);
		}
		else
		{
			response.sendRedirect("index.html");
			
		}*/
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
HttpSession session=request.getSession(false);
		
		
		process(request,response);
		
	}

}