package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.Dao.UserDaoRDBMS;
import com.nucleus.Entity.User;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/CheckerServlet4")
public class CheckerServlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CheckerServlet4() {
        super();
       
    }
    User user;
    
    
   void process(HttpServletRequest request, HttpServletResponse response)
    
    {
    	
	   PrintWriter out=null;
    	try{
    	 out=response.getWriter();
    	}
    	catch(IOException e)
    	{
    		e.printStackTrace();
    	}
    	String crud=request.getParameter("crud");
    	
    	
    	
    	
    	
    	//out.println(crud);
    	//request.setAttribute("action",crud);
    	
    	if(crud!=null)
    	{
    		
    		
    		if(crud.equals("authorizedeletedrecord"))
    			
    		{
    			request.setAttribute("authorizedeletedrecord",crud);

    			RequestDispatcher rd=request.getRequestDispatcher("CheckerServlet5");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    			
    			
    			
    		}
    		
    		
    		
    		
    		if(crud.equals("authorizemodifiedrecord"))
    		{
    			request.setAttribute("authorizemodifiedrecord",crud);

    			RequestDispatcher rd=request.getRequestDispatcher("CheckerServlet5");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    		
    		
    		
    		
    		
    		if(crud.equals("rejectnewrecord"))
    		{
    			
    			System.out.println(crud);
    			request.setAttribute("rejectnew",crud);
    			RequestDispatcher rd=request.getRequestDispatcher("CheckerServlet5");
    			
    			try {
					rd.forward(request,response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		
    		
    		
    		
    	
    	if(crud.equals("create"))
    	{
    		try{
    			
    	   // RequestDispatcher rd=new RequestDispatcher("Customer");

                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache"); // HTTP 1.0
               response.setDateHeader("Expires", 0); // Proxies.
    			
    		response.sendRedirect("Customer.jsp");
    			
    		}
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	
    	
    	
    	
    	if(crud.equals("retrive"))
    	{
    		try{
    		response.sendRedirect("retrive1.jsp");
    		}
    		
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	
    	if(crud.equals("allrecord"))
    	{
    		
    		try{
        		
    			
    			request.setAttribute("all",crud);
    			RequestDispatcher rd=request.getRequestDispatcher("CheckerServlet5");
    			
    			rd.forward(request,response);
    			
    			
    			
    			
    			
        		}
        		
        		catch(ServletException | IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    	}
    	
    	
    	
    	
    	

    	if(crud.equals("update"))
    	{
    		
    		try{
    			
        		
    			
    			response.sendRedirect("update.jsp");
    			
    			
    			
    			
    			
        		}
        		
        		catch(IOException e)
        		{
        			e.printStackTrace();
        		}
    		
    	}
    	
    	
    	
    	if(crud.equals("delete"))
    	{
    		try{
    		response.sendRedirect("delete.jsp");
    		}
    		
    		catch(IOException e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    	
    	}
    	
    }
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		process(request,response);
		
    /*HttpSession session=request.getSession(false);
    
 
    
  
    User user=(User)session.getAttribute("user");
	
    
	if(user!=null)	
		
	{
		process(request,response);
	}
	else
	{
		response.sendRedirect("index.html");
		
	}
	*/
	
	
	
    	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	
	}

}