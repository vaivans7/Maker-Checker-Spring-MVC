package com.nucleus.Filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebFilter("/*")
public class MainFilter implements Filter {

    
    public MainFilter() {
        // TODO Auto-generated constructor stub
    }


	public void destroy() {
		// TODO Auto-generated method stub
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		//chain.doFilter(request, response);
		
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse res=(HttpServletResponse)response;
		
		 /* HttpSession session = req.getSession(false);         
	        if (session == null || session.getAttribute("user") == null) {
	            res.sendRedirect("index.html"); // No logged-in user found, so redirect to login page.
	            res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	            res.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	            res.setDateHeader("Expires", 0);
	        } else {
	            chain.doFilter(req, res);  
	        }
		
		
		*/
		
		
	//	chain.doFilter(request, response);
		
	
		HttpSession session=req.getSession(false);
		String loginUri=req.getContextPath()+"/Servlet2";
		String loginUri1=req.getContextPath()+"/User.html";
		String loginUri2=req.getContextPath()+"/index.html";
		String loginUri3=req.getContextPath()+"/checker.html";
		
		
		boolean loggedIn=session!=null && session.getAttribute("user")!=null;
		boolean loginRequest=req.getRequestURI().equals(loginUri);
		boolean loginRequest1=req.getRequestURI().equals(loginUri1);
		boolean loginRequest2=req.getRequestURI().equals(loginUri2);
		boolean loginRequest3=req.getRequestURI().equals(loginUri3);
		
		
		if(loggedIn || loginRequest || loginRequest1 || loginRequest2 || loginRequest3 )
		{
			chain.doFilter(request, response);
		}
		
		else if(session == null || session.getAttribute("user") == null)
		{
			      res.sendRedirect("index.html"); // No logged-in user found, so redirect to login page.
			  
			 
	            res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	            res.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	            res.setDateHeader("Expires", 0);
		
		
		
		
		
		
	}
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}