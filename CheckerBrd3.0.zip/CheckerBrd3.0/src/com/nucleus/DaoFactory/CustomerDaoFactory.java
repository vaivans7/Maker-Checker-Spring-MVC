package com.nucleus.DaoFactory;

import com.nucleus.Dao.UserDao;
import com.nucleus.Dao.UserDaoRDBMS;

public class CustomerDaoFactory {

	
	
	public void demo()
	{
		
		
	}
	
	
	static public UserDao getCustomerDaoObject(String type)
	{
		
		UserDao userdao=null;
		
		if(type.equals("rdbms"))
		{
			userdao=new UserDaoRDBMS();
		}
		/*
		else if(type.equals("xml"))
		{
			studentDao=new StudentXmlDaoImplementation();
		}
		*/
		
		
		
		return userdao;
	}
	
	
}
