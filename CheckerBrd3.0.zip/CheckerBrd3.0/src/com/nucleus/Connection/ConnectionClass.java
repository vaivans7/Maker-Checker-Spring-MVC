package com.nucleus.Connection;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.sql.DriverManager;

public class ConnectionClass {
	
	
  
  Connection con=null;
  
  public Connection getDBConnection()
	{
		
	  FileReader fr=null;
	
		try {
		
			try {
				fr=new FileReader("D:\\navneet\\Brd3.0\\src\\db.properties");
				
				Properties properties=new Properties();
				properties.load(fr);
				Class.forName(properties.getProperty("connection"));
			    con=DriverManager.getConnection(properties.getProperty("driver"),"sh","sh");
			} catch (IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			finally
			{
				try {
					fr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
		}
		
		
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		
		return con;
	}
		
		
		
	public void closeDBConnection()
	{
			try
			{
				con.close();
			}
			
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
	
	
	

}



