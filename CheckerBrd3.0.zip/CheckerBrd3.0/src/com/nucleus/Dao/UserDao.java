package com.nucleus.Dao;

import java.util.ArrayList;

import com.nucleus.Entity.Customer;
import com.nucleus.Entity.User;

public interface UserDao {

	public User retrive(String id,String password);
	
	
	public boolean save(Customer customer);
	
	public boolean save(Customer customer,String save);
	
	public Customer retrive(String userid);
	
	public ArrayList<Customer> retriveAll(String order,String sort);
	
	public ArrayList<Customer> retriveAll();
	
	public ArrayList<Customer> retriveAll(String code);
	
	public boolean Update(Customer customer);
	
	public boolean delete(String userid);
	
	public int getFlag(String user,String password);
	
	public void setFlag(String user,String password,int temp);
	
	
	public String getUserSession(String user,String password);
	
	public void setUserSession(String user,String password,String usersession);
	
	public boolean checkprimary(String code);
	
	
}