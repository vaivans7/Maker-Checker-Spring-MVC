package com.nucleus.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;



import com.nucleus.Connection.ConnectionClass;
import com.nucleus.Entity.Customer;
import com.nucleus.Entity.User;
import java.sql.Connection;

public class UserDaoRDBMS implements UserDao {

	 
	
	
	
	
	@Override
	public User retrive(String id,String password) {
		
		
		User user1=null;
		String flag1="";
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			System.out.println(con);
			
			System.out.println("hello");
			PreparedStatement ptmt=con.prepareStatement("select * from user7757 where userid=? and userpassword=?");
			ptmt.setString(1,id);
			ptmt.setString(2,password);
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			
			user.setUserId(rs.getString(1));
			user.setUserPassword(rs.getString(2));
			user.setUserRole(rs.getString(3));
			user1=user;
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				user1=null;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return user1;
		
	}

	@Override
	public boolean save(Customer customer) {
		//PropertyConfigurator.configure("log4j.properties");
		//logger.error("Customer Data Cant be send to DB");
		User user1=null;
		boolean flag=true;
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("insert into customer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			
			Long code=customer.getCustomer_pincode();
			String c=code.toString();
			
			Date date=customer.getCreate_date();
			java.sql.Date sqldate=new java.sql.Date(date.getTime());
			
			
			
			
			ptmt.setString(1,"101");
			ptmt.setString(2,customer.getCustomer_code());
			ptmt.setString(3,customer.getCustomer_name());
			ptmt.setString(4,customer.getCustomer_address1());
			ptmt.setString(5,customer.getCustomer_address2());
			ptmt.setLong(6,code);
		    ptmt.setString(7,customer.getEmail_address());
			ptmt.setLong(8,customer.getContact_number());
			ptmt.setString(9,customer.getContact_person());
			ptmt.setString(10,customer.getRecord_status());
			ptmt.setString(11,customer.getActive_inactive_flag());
			ptmt.setDate(12,sqldate);
			ptmt.setString(13,customer.getCreated_by());
			ptmt.setDate(14,null);
			ptmt.setString(15,customer.getModified_by());
			ptmt.setDate(16,null);
			ptmt.setString(17,customer.getAuthorized_by());
		
			
			
			
			
			
			int a=ptmt.executeUpdate();
			System.out.println(a);
			if(a>0)
			{
			
		      flag=true;
			  cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		

			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
		
		
		
	
	}

	@Override
	public Customer retrive(String userid) {
		//PropertyConfigurator.configure("log4j.properties");
		//logger.error("Customer Data Cant be retrived to DB");
		Customer customer1=null;
		String flag1="";
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from customer7757 where customer_code=?");
			ptmt.setString(1,userid);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			System.out.println(customer);
				
				
				
			cc.closeDBConnection();
			
			customer1=customer;
		   
			}
			
			
			else
			{
				
				customer1=null;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}


		 return customer1;
	}

	@Override
	public ArrayList<Customer> retriveAll(String order,String sort) {
		
		//PropertyConfigurator.configure("log4j.properties");
		//logger.error("All Customer Data Cant be send to DB");
		ArrayList<Customer>alist=new ArrayList();
		
		String flag1="";
		try
		{
			
			
			String finalorder=order+" "+sort;
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from customer7757 order by ?");
			
			ptmt.setString(1,order);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			while(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			
				
				alist.add(customer);
				
		
			
			
		   
			}
			
		
			cc.closeDBConnection();
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}


		 return alist;
		
		
		
	}

	@Override
	public boolean Update(Customer customer) {
		
		//PropertyConfigurator.configure("log4j.properties");
		//logger.error("Customer Data Cant be updated to DB");
		
		boolean flag=false;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			//System.out.println("final customer: "+customer.getCustomer_code().length());
			System.out.println(customer);
			
			Date cdate=customer.getCreate_date();
			Date udate=customer.getModified_date();
			Date adate=customer.getAuthorized_date();
			
	
			
			
			java.sql.Date csqldate=null;
			java.sql.Date usqldate=null;
			java.sql.Date asqldate=null;
			
			
			if(cdate!=null)
			{
				csqldate=new java.sql.Date(cdate.getTime());
			}
			
			if(udate!=null)
			{
				usqldate=new java.sql.Date(udate.getTime());
			}
			
			if(adate!=null)
			{
				asqldate=new java.sql.Date(adate.getTime());
			}
			
		
			
			
			PreparedStatement ptmt=con.prepareStatement("update customer7757 set custome_name=?,customer_address1=?,customer_address2=?,customer_pincode=?,email_address=?,contact_number=?,contact_person=?,record_status=?,active_inactive_flag=?,create_date=?,created_by=?,modified_date=?,modified_by=?,authorized_date=?,authorized_by=? where customer_code=?");
			
			//ptmt.setString(1,customer.getCustomer_code());
			ptmt.setString(1,customer.getCustomer_name());
			ptmt.setString(2,customer.getCustomer_address1());
			ptmt.setString(3,customer.getCustomer_address2());
			ptmt.setLong(4,customer.getCustomer_pincode());
			ptmt.setString(5,customer.getEmail_address());
			ptmt.setLong(6,customer.getContact_number());
			ptmt.setString(7,customer.getContact_person());
			ptmt.setString(8,customer.getRecord_status());
			ptmt.setString(9,customer.getActive_inactive_flag());
			ptmt.setDate(10,csqldate);
			ptmt.setString(11,customer.getCreated_by());
			ptmt.setDate(12, usqldate);
			ptmt.setString(13,customer.getModified_by());
			ptmt.setDate(14,asqldate);
			ptmt.setString(15,customer.getAuthorized_by());
			ptmt.setString(16,customer.getCustomer_code().trim());
			
		
		    int a=ptmt.executeUpdate();
			
			if(a>0)
			{
				
				
		      flag=true;
		      
		      
			  cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		

			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
		
		
		
		
		
		
		
		
		
	
	}

	@Override
	public boolean delete(String userid) {
		
		//PropertyConfigurator.configure("log4j.properties");
		//logger.error("Customer Data Cant be deleted from DB");
		User user1=null;
		boolean flag=false;
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("delete from customer7757 where customer_code=?");
			ptmt.setString(1,userid);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			
			flag=true;
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public int getFlag(String user, String password) {
		
		
		int flag1=0;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			
			
			PreparedStatement ptmt=con.prepareStatement("select flag from user7757 where userid=? and userpassword=?");
			ptmt.setString(1,user);
			ptmt.setString(2,password);
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			
			
			flag1=rs.getInt(1);
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
		
		return flag1;
	}

	@Override
	public void setFlag(String user, String password, int temp) {
		

		int flag1=0;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			
			
			PreparedStatement ptmt=con.prepareStatement("update user7757 set flag=? where userid=? and userpassword=?");
			ptmt.setInt(1,temp);
			ptmt.setString(2,user);
			ptmt.setString(3,password);
			
		   ptmt.executeUpdate();
			
			cc.closeDBConnection();
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
	}

	@Override
	public String getUserSession(String user, String password) {
		String flag1=null;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			
			
			PreparedStatement ptmt=con.prepareStatement("select usersession from user7757 where userid=? and userpassword=?");
			ptmt.setString(1,user);
			ptmt.setString(2,password);
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			
			
			flag1=rs.getString(1);
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
		
		return flag1;
		
		
	}

	@Override
	public void setUserSession(String user, String password, String usersession) {
		String flag1=null;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			
			
			PreparedStatement ptmt=con.prepareStatement("update user7757 set usersession=? where userid=? and userpassword=?");
			ptmt.setString(1,usersession);
			ptmt.setString(2,user);
			ptmt.setString(3,password);
			
			ptmt.executeQuery();
			
			cc.closeDBConnection();
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

	@Override
	public boolean checkprimary(String code) {
		

		boolean flag=false;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from customer7757 where customer_code=?");
			ptmt.setString(1,code);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			flag=true;
			
			
				
				
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			flag=false;
		}


		 return flag;
		
		
		
	}

	@Override
	public ArrayList<Customer> retriveAll() {
		
		
ArrayList<Customer>alist=new ArrayList();
		
		String flag1="";
		try
		{
			
			
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from customer7757");
			
			
			
			
			ResultSet rs=ptmt.executeQuery();
			
			while(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			
				
				alist.add(customer);
				
		
			
			
		   
			}
			
		
			cc.closeDBConnection();
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}


		 return alist;
		
		
	}

	@Override
	public boolean save(Customer customer, String save) {
		User user1=null;
		boolean flag=true;
		
		if(save.equals("modifyapprove"))
		{
			try
			{
				User user=new User();
				
				ConnectionClass cc=new ConnectionClass();
				Connection con=cc.getDBConnection();
				
				PreparedStatement ptmt=con.prepareStatement("insert into customer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				
				
				Long code=customer.getCustomer_pincode();
				String c=code.toString();
				
				Date cdate=customer.getCreate_date();
				Date udate=customer.getModified_date();
				Date adate=customer.getAuthorized_date();
				
		
				
				
				java.sql.Date csqldate=null;
				java.sql.Date usqldate=null;
				java.sql.Date asqldate=null;
				
				
				if(cdate!=null)
				{
					csqldate=new java.sql.Date(cdate.getTime());
				}
				
				if(udate!=null)
				{
					usqldate=new java.sql.Date(udate.getTime());
				}
				
				if(adate!=null)
				{
					asqldate=new java.sql.Date(adate.getTime());
				}
				
			
				
				ptmt.setString(1,"101");
				ptmt.setString(2,customer.getCustomer_code());
				ptmt.setString(3,customer.getCustomer_name());
				ptmt.setString(4,customer.getCustomer_address1());
				ptmt.setString(5,customer.getCustomer_address2());
				ptmt.setLong(6,code);
			    ptmt.setString(7,customer.getEmail_address());
				ptmt.setLong(8,customer.getContact_number());
				ptmt.setString(9,customer.getContact_person());
				ptmt.setString(10,customer.getRecord_status());
				ptmt.setString(11,customer.getActive_inactive_flag());
				ptmt.setDate(12,csqldate);
				ptmt.setString(13,customer.getCreated_by());
				ptmt.setDate(14,usqldate);
				ptmt.setString(15,customer.getModified_by());
				ptmt.setDate(16,asqldate);
				ptmt.setString(17,customer.getAuthorized_by());
			
				
				
				
				
				
				int a=ptmt.executeUpdate();
				System.out.println(a);
				if(a>0)
				{
				
			      flag=true;
				  cc.closeDBConnection();
				
				
			   
				}
				
				
				else
				{
					
					flag=false;
					cc.closeDBConnection();
				}
			
				
				
				
			

				
			}
			
			
			
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return flag;
			
		}
		
		
		
		else if(save.equals("deleteauthorize"))
			
		{
			
			try
			{
				User user=new User();
				
				ConnectionClass cc=new ConnectionClass();
				Connection con=cc.getDBConnection();
				
				PreparedStatement ptmt=con.prepareStatement("insert into customer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				
				
				Long code=customer.getCustomer_pincode();
				String c=code.toString();
				
				Date cdate=customer.getCreate_date();
				Date udate=customer.getModified_date();
				Date adate=customer.getAuthorized_date();
				
		
				
				
				java.sql.Date csqldate=null;
				java.sql.Date usqldate=null;
				java.sql.Date asqldate=null;
				
				
				if(cdate!=null)
				{
					csqldate=new java.sql.Date(cdate.getTime());
				}
				
				if(udate!=null)
				{
					usqldate=new java.sql.Date(udate.getTime());
				}
				
				if(adate!=null)
				{
					asqldate=new java.sql.Date(adate.getTime());
				}
				
			
				
				ptmt.setString(1,"101");
				ptmt.setString(2,customer.getCustomer_code().trim());
				ptmt.setString(3,customer.getCustomer_name());
				ptmt.setString(4,customer.getCustomer_address1());
				ptmt.setString(5,customer.getCustomer_address2());
				ptmt.setLong(6,code);
			    ptmt.setString(7,customer.getEmail_address());
				ptmt.setLong(8,customer.getContact_number());
				ptmt.setString(9,customer.getContact_person());
				ptmt.setString(10,customer.getRecord_status());
				ptmt.setString(11,customer.getActive_inactive_flag());
				ptmt.setDate(12,csqldate);
				ptmt.setString(13,customer.getCreated_by());
				ptmt.setDate(14,usqldate);
				ptmt.setString(15,customer.getModified_by());
				ptmt.setDate(16,asqldate);
				ptmt.setString(17,customer.getAuthorized_by());
			
				
				
				
				
				
				int a=ptmt.executeUpdate();
				System.out.println(a);
				if(a>0)
				{
				
			      flag=true;
				  cc.closeDBConnection();
				
				
			   
				}
				
				
				else
				{
					
					flag=false;
					cc.closeDBConnection();
				}
			
				
				
				
			

				
			}
			
			
			
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return flag;
			
			
			
			
			
		}
		
		
		
		
		
		
		else {
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("insert into customer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			
			Long code=customer.getCustomer_pincode();
			String c=code.toString();
			
			Date cdate=customer.getCreate_date();
			Date udate=customer.getModified_date();
			Date adate=customer.getAuthorized_date();
			
			java.sql.Date csqldate=null;
			java.sql.Date usqldate=null;
			java.sql.Date asqldate=null;
			
			
			if(cdate!=null)
			{
				csqldate=new java.sql.Date(cdate.getTime());
			}
			
			if(udate!=null)
			{
				usqldate=new java.sql.Date(udate.getTime());
			}
			
			if(adate!=null)
			{
				asqldate=new java.sql.Date(adate.getTime());
			}
			
			
			ptmt.setString(1,"101");
			ptmt.setString(2,customer.getCustomer_code());
			ptmt.setString(3,customer.getCustomer_name());
			ptmt.setString(4,customer.getCustomer_address1());
			ptmt.setString(5,customer.getCustomer_address2());
			ptmt.setLong(6,code);
		    ptmt.setString(7,customer.getEmail_address());
			ptmt.setLong(8,customer.getContact_number());
			ptmt.setString(9,customer.getContact_person());
			ptmt.setString(10,customer.getRecord_status());
			ptmt.setString(11,customer.getActive_inactive_flag());
			ptmt.setDate(12,csqldate);
			ptmt.setString(13,customer.getCreated_by());
			ptmt.setDate(14,usqldate);
			ptmt.setString(15,customer.getModified_by());
			ptmt.setDate(16,asqldate);
			ptmt.setString(17,customer.getAuthorized_by());
		
			
			
			
			
			
			int a=ptmt.executeUpdate();
			System.out.println(a);
			if(a>0)
			{
			
		      flag=true;
			  cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		

			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
		}
		
	}

	@Override
	public ArrayList<Customer> retriveAll(String code) {
		
ArrayList<Customer>alist=new ArrayList();
		
		String flag1="";
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from customer7757 where record_status=?");
			
			ptmt.setString(1,code);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			while(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			
				
				alist.add(customer);
				
		
			
			
		   
			}
			
		
			cc.closeDBConnection();
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}


		 return alist;
		
		
		
	}

}