package com.nucleus.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.nucleus.Connection.ConnectionClass;
import com.nucleus.Entity.Customer;
import com.nucleus.Entity.User;

public class CheckerDaoRDBMS implements UserDao {

	@Override
	public User retrive(String id, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean save(Customer customer) {
		
		System.out.println(customer);
		
		User user1=null;
		boolean flag=true;
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("insert into permanentcustomer7757 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			
			Long code=customer.getCustomer_pincode();
			String c=code.toString();
			
			
			java.sql.Date date1=null;
			java.sql.Date date2=null;
			java.sql.Date date3=null;
			
			Date create_date=customer.getCreate_date();
			Date modified_date=customer.getModified_date();
			
			
			if(create_date!=null)
			{
				date1=new java.sql.Date(create_date.getTime());
			}
			
			else
			{
				date1=null;
			}
			
			
			if(modified_date!=null)
			{
				date2=new java.sql.Date(modified_date.getTime());
			}
			
			else
			{
				date2=null;
			}
			
			
			Date date=customer.getCreate_date();
			date3=new java.sql.Date(date.getTime());
			
			
			
			
			ptmt.setString(1,"101");
			ptmt.setString(2,customer.getCustomer_code());
			ptmt.setString(3,customer.getCustomer_name());
			ptmt.setString(4,customer.getCustomer_address1());
			ptmt.setString(5,customer.getCustomer_address2());
			ptmt.setLong(6,code);
		    ptmt.setString(7,customer.getEmail_address());
			ptmt.setLong(8,customer.getContact_number());
			ptmt.setString(9,customer.getContact_person());
			ptmt.setString(10,"A");
			ptmt.setString(11,customer.getActive_inactive_flag());
			ptmt.setDate(12,date1);
			ptmt.setString(13,customer.getCreated_by());
			ptmt.setDate(14,date2);
			ptmt.setString(15,customer.getModified_by());
			ptmt.setDate(16,date3);
			ptmt.setString(17,customer.getAuthorized_by());
		
			
			
			
			
			
			int a=ptmt.executeUpdate();
			System.out.println(a);
			if(a>0)
			{
			
		      flag=true;
			  cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		

			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
		
		
	}

	@Override
	public Customer retrive(String userid) {
		Customer customer1=null;
		String flag1="";
		try
		{
			User user=new User();
			System.out.println("dao id "+userid);
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from permanentcustomer7757 where customer_code=?");
			ptmt.setString(1,userid.trim());
			
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			//System.out.println(customer);
				System.out.println("dao customer "+customer);
				
			customer1=customer;	
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				customer1=null;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}


		System.out.println("dao "+customer1);
		 return customer1;
	}

	@Override
	public ArrayList<Customer> retriveAll(String order, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Customer> retriveAll() {
		
ArrayList<Customer>alist=new ArrayList();
		
		String flag1="";
		try
		{
			
			
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("select * from permanentcustomer7757");
			
			
			
			
			ResultSet rs=ptmt.executeQuery();
			
			while(rs.next())
			{
			
			
			
			Customer customer=new Customer();
			customer.setCustomer_code(rs.getString(2));
			customer.setCustomer_name(rs.getString(3));
			customer.setCustomer_address1(rs.getString(4));
			customer.setCustomer_address2(rs.getString(5));
			customer.setCustomer_pincode(rs.getLong(6));
			customer.setEmail_address(rs.getString(7));
			customer.setContact_number(rs.getLong(8));
			customer.setContact_person(rs.getString(9));
			customer.setRecord_status(rs.getString(10));
			customer.setActive_inactive_flag(rs.getString(11));
			customer.setCreate_date(rs.getDate(12));
			customer.setCreated_by(rs.getString(13));
			customer.setModified_date(rs.getDate(14));
			customer.setModified_by(rs.getString(15));
			customer.setAuthorized_date(rs.getDate(16));
			customer.setAuthorized_by(rs.getString(17));
			
			
			
				
				alist.add(customer);
				
		
			
			
		   
			}
			
		
			cc.closeDBConnection();
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}

     System.out.println(alist);
		 return alist;
	}

	@Override
	public boolean Update(Customer customer) {
	
		boolean flag=false;
		try
		{
			
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			//System.out.println("final customer: "+customer.getCustomer_code().length());
			//System.out.println(customer);
			
			Date cdate=customer.getCreate_date();
			Date udate=customer.getModified_date();
			Date adate=customer.getAuthorized_date();
			
	
			
			
			java.sql.Date csqldate=null;
			java.sql.Date usqldate=null;
			java.sql.Date asqldate=null;
			
			
			if(cdate!=null)
			{
				csqldate=new java.sql.Date(cdate.getTime());
			}
			
			if(udate!=null)
			{
				usqldate=new java.sql.Date(udate.getTime());
			}
			
			if(adate!=null)
			{
				asqldate=new java.sql.Date(adate.getTime());
			}
			
		
			
			
		
			
			
			PreparedStatement ptmt=con.prepareStatement("update permanentcustomer7757 set custome_name=?,customer_address1=?,customer_address2=?,customer_pincode=?,email_address=?,contact_number=?,contact_person=?,record_status=?,active_inactive_flag=?,create_date=?,created_by=?,modified_date=?,modified_by=?,authorized_date=?,authorized_by=? where customer_code=?");
			
			//ptmt.setString(1,customer.getCustomer_code());
			ptmt.setString(1,customer.getCustomer_name());
			ptmt.setString(2,customer.getCustomer_address1());
			ptmt.setString(3,customer.getCustomer_address2());
			ptmt.setLong(4,customer.getCustomer_pincode());
			ptmt.setString(5,customer.getEmail_address());
			ptmt.setLong(6,customer.getContact_number());
			ptmt.setString(7,customer.getContact_person());
			ptmt.setString(8,customer.getRecord_status());
			ptmt.setString(9,customer.getActive_inactive_flag());
			ptmt.setDate(10,csqldate);
			ptmt.setString(11,customer.getCreated_by());
			ptmt.setDate(12, usqldate);
			ptmt.setString(13,customer.getModified_by());
			ptmt.setDate(14,asqldate);
			ptmt.setString(15,customer.getAuthorized_by());
			ptmt.setString(16,customer.getCustomer_code().trim());
			
		
		    int a=ptmt.executeUpdate();
			
			if(a>0)
			{
				
				
		      flag=true;
		      
		      
			  cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		

			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
		
		
		
	}

	@Override
	public boolean delete(String userid) {
		User user1=null;
		boolean flag=false;
		try
		{
			User user=new User();
			
			ConnectionClass cc=new ConnectionClass();
			Connection con=cc.getDBConnection();
			
			PreparedStatement ptmt=con.prepareStatement("delete from permanentcustomer7757 where customer_code=?");
			ptmt.setString(1,userid);
			
			
			ResultSet rs=ptmt.executeQuery();
			
			if(rs.next())
			{
			
			
			
			
			flag=true;
			cc.closeDBConnection();
			
			
		   
			}
			
			
			else
			{
				
				flag=false;
				cc.closeDBConnection();
			}
		
			
			
			
		
	
			
		}
		
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public int getFlag(String user, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setFlag(String user, String password, int temp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getUserSession(String user, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setUserSession(String user, String password, String usersession) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean checkprimary(String code) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean save(Customer customer, String save) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<Customer> retriveAll(String code) {
		// TODO Auto-generated method stub
		return null;
	}

}