window.onload=function()
{
	console.log("In window");
	var for1=document.getElementById("customerform");
	for1.reset();
	}