var ccode=document.getElementByName("customercode").value;
var cname=document.getElementByName("customername").value;
var address1=document.getElementByName("address1").value;
var address2=document.getElementByName("address2").value;
var pincode=document.getElementByName("pincode").value;
var email=document.getElementByName("email").value;
var cnum=document.getElementByName("number").value;
var person=document.getElementByName("person").value;


function myFunction(){
	
     var cust_code_len=$("#cust_code").val().length;
     if(cust_code_len>10)
     {
     	$("#cust_length").show();
     }
     else
     {
     	$("#cust_length").hide();
     }  

     var cust_name_len=$("#cust_name").val().length;
     if(cust_name_len>2)
     {
     	$("#cust_name_len").show();
     }
     else
     {
     	$("#cust_name_len").hide();
     } 

     var cust_add1_len=$("#cust_add1").val().length;
     if(cust_add1_len>2)
     {
     	$("#cust_add1_len").show();
     }
     else
     {
     	$("#cust_add1_len").hide();
     } 

     var cust_add2_len=$("#cust_add2").val().length;
     if(cust_add2_len>2)
     {
     	$("#cust_add2_len").show();
     }
     else
     {
     	$("#cust_add2_len").hide();
     } 

     var cust_pin_len=$("#cust_pin").val().length;
     if(cust_pin_len>2)
     {
     	$("#cust_pin_len").show();
     }
     else
     {
     	$("#cust_pin_len").hide();
     } 

     var email_len=$("#cust_email").val().length;
     if(email_len>20)
     {
     	$("#email_len").show();
     }
     else
     {
     	$("#email_len").hide();
     } 

     var cont_num_len=$("#cont_num").val().length;
     if(cont_num_len>2)
     {
     	$("#cont_num_len").show();
     }
     else
     {
     	$("#cont_num_len").hide();
     } 

     var Per_len=$("#cont_Per").val().length;
     if(Per_len>2)
     {
     	$("#Per_len").show();
     }
     else
     {
     	$("#Per_len").hide();
     } 


}

function dataLength(str,len)
{
	var length=str.length();
	if(length<len)
		{
		return true;
		}
	else
		{
		return false;
		}
}

function emailvalidation(email_verify)
{
	var atposition=email_verify.indexOf("@");  
	var dotposition=email_verify.lastIndexOf(".");  
	if (atposition<1 || dotposition<atposition+2 || dotposition+2>=email_verify.length){  
	//  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
	  return false;
	}
	
}

function specialCharacter(str)
{
	var regex = /^[A-Za-z0-9 ]+$/;
	var isValid = regex.test(str);
	if(!isValid)
		{
		return false;
		}
	else
		{
		return true;
		}
	
}

function mandatory()
{
	
}


document.getElementByName("create").addEventListener("click",myfunc);
function myfunc()
{

	
	
}