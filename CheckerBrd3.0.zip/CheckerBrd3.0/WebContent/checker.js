var list1 =[];
var list2=[];
var list3=[];

function approve(str)
{
	debugger;
	
	var name1=str.name;
	
	var radioValue = $("input[name="+name1+"]:checked").val();
	if(radioValue=="Authorize"){
		list1.push({code:name1,status:1});	
	}
	else{
		list1.push({code:name1,status:0});
	}
	
	

}


function approve2(str)
{
	debugger;
	
	var name1=str.name;
	
	var radioValue = $("input[name="+name1+"]:checked").val();
	if(radioValue=="Authorize"){
		list2.push({code:name1,status:1});	
	}
	else{
		list2.push({code:name1,status:0});
	}
	
	

}



function approve3(str)
{
	debugger;
	
	var name1=str.name;
	
	var radioValue = $("input[name="+name1+"]:checked").val();
	if(radioValue=="Authorize"){
		list3.push({code:name1,status:1});	
	}
	else{
		list3.push({code:name1,status:0});
	}
	
	

}

function finalsubmit6(){
	debugger;
	$.post('/CheckerServlet5', {'someKeyName': list3});
}


function finalsubmit5(){
	debugger;
	$.post('/CheckerServlet5', {'someKeyName': list2});
}


function finalsubmit(){
	debugger;
	$.post('/CheckerServlet5', {'someKeyName': list1});
}


function approve2(str)
{
	debugger;
	
	var name1=str.name;
	
	
	if($("input[name="+name1+"]:checked").val()=="reject"){
		list2.push({code:name1,status:1});	
	}
	
	
	

}


function finalsubmit2(){
	debugger;
	$.post('/CheckerServlet5', {'someKeyName': list2});
}


function finalsubmit3(str){
	debugger;
	
	var name1=str.name;
	
	
	$.post('/Servlet3?', {'someKeyName': name1});
}


function finalsubmit4(str){
	debugger;
	
	
	
	var name1=str.name;

	
	$.post('/Servlet3?', {'someKeyName': name1});
}

